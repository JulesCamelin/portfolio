# Créé par jucamelin, le 30/03/2023 en Python 3.7
import tkinter as tk # on importe les bibliothèques nécesssaires
from tkinter import HORIZONTAL
from random import *
from tkinter import ttk
from PIL import Image, ImageTk
import pygame as py
from math import sqrt
import csv
import os

def temps_():
    '''fonction qui montre le temps de jeu dans la toile'''
    global horaire, temps_en_haut, mort   # on prend les valeurs en global qui nous interresse
    if mort==False: #si cupidon est encore en vie alors :
        horaire+=1 # on aumente de 1 horaire pour faire en sorte que ce soit un chrono
        toile.itemconfig(temps_en_haut,text="temps de jeu : "+str(horaire)) # on modifie le temps sur la toile
    toile.after(1000,temps_) # on rapelle en boucle la fonction (récursivité) tout les 1s

def music_en_fond():
    '''fonction qui mettra de la music en fond'''
    global music_fond # on prend les valeurs en global qui nous interresse
    music_fond.stop() # je stop la music
    py.mixer.init() # on initialise la musique
    music_fond = py.mixer.Sound('music_fond.wav') # on ouvre la musique de oh_no2.wav
    music_fond.play(0) # on joue la music
    toile.after(86000,music_en_fond)  # on rapelle en boucle la fonction (récursivité)




def battement_aille ():
    '''fonction qui prend en parametre un compteur. La fonction modifie l'image de cupidon
    en fonction du compteur pour qu'il batte des ailles en continue'''
    global x_cupidon, y_cupidon, action,mort,t,hit # on prend les valeurs en global qui nous interresse
    if mort==False: #si cupidon est encore en vie alors :
        if  action=='passif' and hit==False: # on verifie que l'action est bien passif et si hit est en false
            t=t+1       # on incrémente le compteur de récursivité
            if direction == "droite" :  # si la direction est la droite alors on creer l'image de cupidon en direction de la droite
                toile.itemconfigure(cupidon, image=images_cupidon[t%4+13] )
            else: # sinon on creer l'image de cupidon en direction de la gauche
                toile.itemconfigure(cupidon, image=images_cupidon[t%4] )
            toile.coords(cupidon, x_cupidon, y_cupidon)           # on ajoute cupidon a la toile avec ses coordonnées
            fenetre.after(100,battement_aille)                # on rapelle en boucle la fonction (récursivité)

def mort_cupidon(t):
    '''fonction qui est appeler quand cupidon est toucher par un monstre et qui defile les image de mort de cupidon'''
    global direction,score, horaire,game_over,score_de_fin,temps_de_partie_fin # on prend les valeurs en global qui nous interresse

    if t==5:   #quand t est égal a 5 on fait :
        toile.delete(cupidon) #on supprime cupidon de la toile
        game_over=toile.create_text(500,300,text="GAME OVER !",font=('Arial',50),fill="red") #on affiche un message en rouge disant que vous avez perdu
        score_de_fin=toile.create_text(500,200,text="Votre score est de "+str(score),font=('Arial',30),fill="black") #on affiche le score de la partie
        temps_de_partie_fin=toile.create_text(500,150,text="Votre temps de partie est de : "+str(horaire)+ " secondes",font=('Arial',30),fill="black") # on affiche le temps de la partie du joueur en gros quand cupidon est mort
    if direction=='gauche' and t<5: # quand t est in ferieur a 5 et de direction gauche on fait changer  les images de cupidon sur la toile en faisant en sorte qui meurt
                toile.itemconfigure(cupidon, image=images_cupidon[t%5+8] ) # on modifie l'image de cupidon sur la toile
    if  direction == 'droite' and t<5: # quand t est in ferieur a 5 et de direction droite on fait changer  les images de cupidon sur la toile en faisant en sorte qui meurt
                toile.itemconfigure(cupidon, image=images_cupidon[t%5+21]) # on modifie l'image de cupidon sur la toile
    t=t+1 # on incrémente le compteur de récursivité
    fenetre.after(80,mort_cupidon,t) # on rapelle en boucle la fonction (récursivité)

def vie():
    '''fonction qui fait baisser ou augmenter la vie'''
    global bouton,afficher_nom_utilisateur,health,bouton_restard,bouton2,mort,time_shield,x_cupidon,y_cupidon,bouclier,hit,music_fond,music_bonus # on prend les valeurs en global qui nous interresse
    health-=1 # on diminue la vie de 1
    toile.itemconfig(health_bar,image=images_health[health]) # on modifie l'image de la barre de vie sur la toile
    if health>0: # si la vie est supérieur a 0
        hit =True # on definit que cupidon est toucher
        cupidon_rouge(0) # on appelle la fonction cupidon_rouge
        monstres_recul(t) # on appelle la fonction monstres_recul
    else:
        mort=True   #le cupidon est mort
        bouton2.destroy() # je detruit le bouton numero2
        music_fond.stop() # je stop la music
        music_bonus.stop() # je stop la music
        mort_cupidon(0)#on apelle la fonction mort cupidon pour faire defiler les images de mort de cupidon
        py.mixer.init() # on initialise la musique
        oh_no = py.mixer.Sound('oh_no2.wav') # on ouvre la musique de oh_no2.wav
        oh_no.set_volume(0.3) # je diminue le volume a 30%
        oh_no.play(0) # on joue la music
        music = py.mixer.Sound('super-mario-bros_2.wav') # on ouvre la musique de super-mario-bros_2.wav
        music.set_volume(0.3)# je diminue le volume a 30%
        music.play(0) #on joue la musique
        bouton_restard = tk.Button(fenetre, text='ACCEUIL', command =lambda: ( recommence_la_partie())) # on crée un bouton pour "recommencer" le jeu
        bouton_restard.pack() # on ajoute le bouton a la toile
        bouton = tk.Button(fenetre, text='Quitter', command = fenetre.destroy)  # on crée un bouton pour quitter le jeu
        bouton.pack()       # on place le bouton dans la fenêtre




def sons_mario_toucher(t):
    global cupidon_toucher_son # on prend les valeurs en global qui nous interresse
    '''fonction qui ferra du son quand mario est toucher '''
    if t==0: # si t vaut 0 alors
        cupidon_toucher_son.play(0) # on joue la son cupidon_toucher_son
    if t==3: # si t vaut 3
        cupidon_toucher_son.stop() # on arrete la musique cupidon_toucher_son
    if t<4: # si t est inferieur a 4
        toile.after(1080,sons_mario_toucher,t+1) # on appelle la fonction pour qu'elle tourne en boucle







def cupidon_rouge(t):
    '''fonction qui fera apparaitre cupidon rouge quand il se fera toucher'''
    global image_toucher, direction,cupidon,images_cupidon,hit # on prend les valeurs en global qui nous interresse
    if hit==True: # si cupidon est toucher par un mechant
        if direction == 'gauche' and t==1: # si la direction est égal a gauche et si t vaut 1 alors:
            toile.itemconfigure(cupidon, image=image_toucher[1]) # on modifie l'image de cupidon sur la toile
        if direction == 'droite' and t==1: # si la direction  est égal a droite et si t vaut 2 alors:
            toile.itemconfigure(cupidon, image=image_toucher[0]) # on modifie l'image de cupidon sur la toile
        if direction == 'gauche' and t==2: # si la direction est égal a gauche et si t vaut 2 alors:
            toile.itemconfigure(cupidon, image=images_cupidon[1]) # on modifie l'image de cupidon sur la toile
        if direction == 'droite' and t==2: # si la direction est égal a droite et si t vaut 2 alors:
            toile.itemconfigure(cupidon, image=images_cupidon[14]) # on modifie l'image de cupidon sur la toile
        if direction == 'gauche' and t==3: # si la direction est égal a gauche et si t vaut 3 alors:
            toile.itemconfigure(cupidon, image=image_toucher[3]) # on modifie l'image de cupidon sur la toile
        if direction == 'droite' and t==3: # si la direction est égal a droite et si t vaut 3 alors:
            toile.itemconfigure(cupidon, image=image_toucher[2]) # on modifie l'image de cupidon sur la toile
        if direction == 'gauche' and t==4: # si la direction est égal a gauche et si t vaut 4 alors:
            toile.itemconfigure(cupidon, image=images_cupidon[3]) # on modifie l'image de cupidon sur la toile
        if direction == 'droite' and t==4: # si la direction est égal a droite et si t vaut 4 alors:
            toile.itemconfigure(cupidon, image=images_cupidon[16]) # on modifie l'image de cupidon sur la toile
        if t==5: #si t est egal a 5
            hit=False # on met hit en false
            battement_aille() # on rappelle la fonction battement aile
    if t<7:  # si t est inferieur a 7
        t=t+1 # on incrémente le compteur de récursivité
        toile.after(100,cupidon_rouge,t) # on appelle la fonction pour qu'elle tourne en boucle



def monstres_recul(t):
    """fonction qui fait reculer les monstres apres que le cupidon ait été touché"""
    global x_cupidon,y_cupidon,l_mechant # on prend les valeurs en global qui nous interresse
    for elt in l_mechant: # pour chaque élément dans la liste des mechants :
        if sqrt((x_cupidon-elt[1])**2+(y_cupidon-elt[2])**2)<275: # si la racine du x_cupidon - le x du mechans au carré + la racine du y_cupidon - le y du mechans au carré est inférieur a 275:
            if x_cupidon>elt[1] and elt[1]-20>-50: # si le x_cupidon est superieur au x du mechants et si le x du mechants -20 est plus grand que -50 alors :
                elt[1]-=randint(150,200) # on diminue entre 150 et 200 le x du mechants
            elif x_cupidon<elt[1] and elt[1]+20<1050: # si le x_cupidon est inferieur au x du mechants et si le x du mechants +20 est plus petit que 1050 alors :
                elt[1]+=randint(150,200) # on augmente entre 150 et 200 le x du mechants
            if y_cupidon>elt[2] and elt[2]-10>0:  # si le y_cupidon est superieur au y du mechants et si le y du mechants -10 est plus grand que 0 alors :
                elt[2]-=randint(100,150) # on diminue entre 100 et 150 le y du mechant
            elif y_cupidon<elt[2] and elt[2]-10<600: # si le y_cupidon est inferieur au y du mechants et si le y du mechants -10 est plus petit que 600 alors :
                elt[2]+=randint(100,150) # on augmente entre 100 et 150 le y du mechant
            toile.coords(elt[0],elt[1],elt[2]) # on modifie les coordonées du mechants sur la toile
    if t<8: # si t est inferieur a 8
        toile.after(25,monstres_recul,t+1) # on appelle la fonction pour qu'elle tourne en boucle





def deplacement_cupidon(event):
    '''fonction qui permet de faire deplacer cupidon avec les fleche du clavier et de le faire tirer en appuyant sur la barre espace'''
    global x_cupidon, y_cupidon,depart_fleche, t, direction,carapace_rouge ,mort,touche , temps_de_jeu ,double_fleche, fleche_destructive ,fusee_rouge, image_bouclier, temps_bouclier, bouclier, l_mechant,time_shield,horaire,affiche_temps_bouclier,temps_bouclier,bouclier_action,bouclier_sur_toile,mine_sur_la_toile,mine_vf   # on prend les valeurs en global qui nous interresse
    if mort==False: #si cupidon est encore en vie alors :
        touche=event.keysym # on récupère le caractère de la touche appuyée
        if touche=='Left':  #si la touche gauche est appuyer on deplace de 15 pixels cupidon sur la gauche et on met la direction a gauche
            direction='gauche'
            x_cupidon=x_cupidon-15   # on diminue l'abscisse de cupidon
            toile.coords(cupidon, x_cupidon, y_cupidon)    # on déplace l'image de cupidon sur la toile


        elif touche=="Right": #si la touche droite est appuyer on deplace de 15 pixels cupidon sur la droite et on met la direction a droite
            direction='droite'
            x_cupidon=x_cupidon+15    # on augmente l'abscisse de cupidon
            toile.coords(cupidon, x_cupidon, y_cupidon)         # on déplace l'image de cupidon sur la toile


        if touche=='Down':   #si la touche bas est appuyer on deplace de 15 pixels cupidon en bas
                y_cupidon=y_cupidon+15    # on augmente l'ordonné de cupidon
                toile.coords(cupidon, x_cupidon, y_cupidon)              # on déplace l'image de cupidon sur la toile


        elif touche=="Up": #si la touche haut est appuyer on deplace de 15 pixels cupidon en haut
            y_cupidon=y_cupidon-15      # on diminue l'ordonné de cupidon
            toile.coords(cupidon, x_cupidon, y_cupidon)            # on déplace l'image de cupidon sur la toile

        if x_cupidon>=970:   # je definit les limites du jeu pour que cupidon ne puisse pas sortir de la toile
            x_cupidon=x_cupidon-15
        if x_cupidon<=35:
            x_cupidon=x_cupidon+15
        if y_cupidon>=570:
            y_cupidon=y_cupidon-15
        if y_cupidon<=30:
            y_cupidon=y_cupidon+15

        if touche=='space': #si la touche espace est toucher on va faire tirer cupidon
                    depart_fleche.play(0) # je joue la musique d'un bruit de flèche
                    if direction == "gauche":  # si cupidon est de gauche on fait ca :
                        x_fleche=x_cupidon-20  # on definit les coordonées de la fleche
                        y_fleche=y_cupidon-13
                        tirer(0)  # on appel la fonction tirer
                        l_fleche.append([toile.create_image((x_fleche, y_fleche), image =images_fleche[0]),x_fleche,y_fleche,direction,'visible']) # on ajoute les fleches à la fenêtre et on l'ajoute dans une liste
                    if direction=="droite":     # si cupidon est de droite on fait ca :
                        x_fleche=x_cupidon+20   # on definit les coordonées de la fleche
                        y_fleche=y_cupidon-13
                        tirer(0) # on appel la fonction tirer
                        l_fleche.append([toile.create_image((x_fleche, y_fleche), image =images_fleche[1]),x_fleche,y_fleche,direction,'visible'])  # on ajoute les fleches à la fenêtre et on l'ajoute dans une liste
        if touche== 'c' and fleche_destructive==True: #si le bonus fleche destructeur est disponible alors:
            depart_fleche.play(0) # je joue la musique d'un bruit de flèche
            fleche_destructive_massive() #on appelle la fonction felche destructive massive
            fleche_destructive=False #on remet la fleche destructive en false

        if touche=='x' and double_fleche==True: # si la touche x est presser et que la double fleche est disponible
            depart_fleche.play(0) # je joue la musique d'un bruit de flèche
            tirer_2_sens() #on appel la fonction tirer2sens
            double_fleche=False #on met double fleche en false pour pas qu'on re rentre dans cette fonction

        if touche=='n' and carapace_rouge==True: # si la touche x est presser et que la double fleche est disponible
            depart_fleche.play(0) # je joue la musique d'un bruit de flèche
            carapace_rouge_tire() #on appel la fonction carapace_rouge_tire
            carapace_rouge=False #on met double fleche en false pour pas qu'on re rentre dans cette fonction


        if bouclier_action==True: # si le bouclier est disponible
            if touche =='b': # si la touche b est presser
                time_shield+=6 # j'augmente le temps du bouclier sur la toile qui est de 6s
                bouclier=toile.create_image(x_cupidon,y_cupidon, image = image_bouclier)  # je créer une image d'un bouclier autour de cupidon
                temps_bouclier=26 # on remet le temps d'obtenir le bouclier a 26 s
                toile.itemconfig(affiche_temps_bouclier,text=" : " +str(temps_bouclier) +" b") # on modifie le temps sur la toile
                bouclier_action=False # je met le bouclier en false pour ne pus qui rentre dans cette fonctions
                toile.coords(bouclier_sur_toile,120,25) # je fais réapparaitre l'image du petit bouclier en haut
        if time_shield>=0: # si le temps du bouclier est suprieur ou egal a 0 :
            toile.coords(bouclier,x_cupidon,y_cupidon)#permet de bouger le bouclier aux meme coordonnées que le cupidon

        if touche =='w' and mine_vf==True: # si le touche w est appuyer et mine_vf est vrai alors :
            mine_sur_la_toile(0) # on appel la fonction mine_sur_la_toile
            mine_vf=False # on remet la mine_vf en false


        if touche=='v' and fusee_rouge==True:  # si la touche v est presser et que la fusee_rouge est disponible
            fusee_en_action() # on appel la fonction fusee_en_action
            fusee_rouge=False # on met fusee_rouge en false pour pas qu'on re rentre dans cette fonction

        for elt in l_mechant: # pour chaque element dans la liste des mechants
            if time_shield>0 and sqrt((x_cupidon-elt[1])**2+(y_cupidon-elt[2])**2)<80: # si les méchants sont dans la fentre et que le bouclierest actif alors
                if abs(y_cupidon-elt[2])<70: # si leur coordonnée sont in férieur a 70
                    if touche=='Right': # si la touche droite est toucher
                        elt[1]+=15 # on augmente les coordonner les x de 15 pour faire reculer le mechants de cupidon
                    elif touche=='Left': # si la touche gauche est toucher
                        elt[1]-=15 # on diminue les x les coordonner de 15 pour faire reculer le mechants de cupidon
                if abs(x_cupidon-elt[1])<70: # si les y des mechants sont inférieur a 70
                    if touche=='Up': # si la touche haut est toucher
                        elt[2]-=15 # on diminue les coordonner du y de 15 pour faire reculer le mechants de cupidon
                    elif touche=='Down': # si la touche bas est toucher
                        elt[2]+=15 # on augmente les coordonnées du y de 15 pour faire reculer le mechants de cupidon
                toile.coords(elt[0],elt[1],elt[2]) # on modifie les coordonées du mechants sur la toile


def mechant_touche_cupidon():
    '''fonction qui est appeler quand cuipdon est toucher par un mechant'''
    global x_cupidon,mort,y_cupidon,l_mechant, health # on prend les valeurs en global qui nous interresse
    if mort==False: #si cupidon est encore en vie alors :
        for elmt in l_mechant: #pour tout les element dans la liste mechants on fait :
                if abs (x_cupidon-elmt[1])< 42 and abs (y_cupidon-elmt[2])< 58 and elmt[4]=='alive' and health ==0: #si les mechants touches cupidon et qu'ils sont en vie alors :
                    vie() #on appelle la fonction mort cupidon
                    mort=True #on definit la mort en true pour arreter le jeu
        toile.after(5,mechant_touche_cupidon) # on rapelle en boucle la fonction (récursivité)



def skill_shield():
    """fonction qui fait apparaitre le bouclier"""
    global time_shield,x_cupidon,y_cupidon,bouclier,temps_bouclier,affiche_temps_bouclier,mort,direction,bouclier_action,music_bonus # on prend les valeurs en global qui nous interresse
    if time_shield>-1: # si le temps du bouclier est supérieur a moins 1 alors
        time_shield-=1 # on diminue le temp du bouclier de 1
    if time_shield==0: # si le temps de bouclier est egal a 0
        toile.delete(bouclier) #on supprime le bouclier de la toile
    if mort==False: #si cupidon est encore en vie alors :
        if temps_bouclier>=1: # si le temps de jeu est superieur ou egal a 1 :
            temps_bouclier=temps_bouclier-1 #on le diminue de 1
            toile.itemconfig(affiche_temps_bouclier,text=" : "+str(temps_bouclier) +" b") # on modifie le temps sur la toile
        if temps_bouclier==1: #si le temps est egal a 1 alors:
            music_bonus.play(0) # on joue la music
        if temps_bouclier==0: # si le temps est égal a 0 alors
            bouclier_action=True #on dit que le bouclier est disponible pour pouvoir se proteger des mechants
            bonus_disponible3(0) # j'appelle la fonction qui fait clignoter le bonus en haut a gauche
    toile.after(1000,skill_shield) # on rapelle en boucle la fonction toute les secondes (récursivité)




def tirer(t):
    '''fonction récursive qui prend en parametre un compteur. La fonction
    va faire défiler les images de cupidon en train de tirer une flèches.
    Elle va également ajouter une flèche à la liste des flèches deja tirer'''
    global action,direction # on prend les valeurs en global qui nous interresse
    if i==3: # quand t vaux 3 on arrete et on remet l'action en passif
        action='passif'
    if direction=='droite' and t < 3: # on fait cela si la direction est la droite et si l'incrémentation (t) est inferieur a 3
        toile.itemconfigure(cupidon, image=images_cupidon[17+t]) # on ajoute l'image de cupidon entrain de tirer a droite
    if direction=='gauche' and t < 3:  # on fait cela si la direction est la gauche et si l'incrémentation (t) est inferieur a 3
        toile.itemconfigure(cupidon, image=images_cupidon[4+t]) # on ajoute l'image de cupidon entrain de tirer a gauche
    if t<3: # si t est plus petit que 3 alors :
        fenetre.after(40,tirer,t+1)  # on rapelle en boucle la fonction (récursivité) et on incrémente le compteur de récursivité





def avancer_fleche():
    '''fonction qui va faire apparaitre et déplacer la fleche jusqua tuer un mechant ou sortir du champ'''
    global l_fleche# on prend les valeurs en global qui nous interresse
    for elmtt in l_fleche : # pour chaque element dans la liste l_fleche on fait :
        if elmtt[3]=='gauche' and elmtt[4]!='carapace':  # si la direction est la gauche et que c'est pas une carapace :
            elmtt[1]=elmtt[1]-7  # on enleve 7 pixels
        elif elmtt[3]=='droite' and elmtt[4]!='carapace': #si la direction est la droite et que c'est pas une carapace :
            elmtt[1]=elmtt[1]+7 # on rajoute 7 pixels
        toile.coords(elmtt[0],elmtt[1],elmtt[2]) #on déplace la fleche sur la toile
    toile.after(20, avancer_fleche) # on appelle la fonction pour qu'elle tourne en boucle


def tirer_2_sens_disponible():
    '''fonction qui affichera le temps de jeu pour donner un bonus'''
    global temps_de_jeu,mort,direction,double_fleche,music_bonus,double_fleche_sur_toile_1,double_fleche_sur_toile # on prend les valeurs en global qui nous interresse
    toile.coords(double_fleche_sur_toile_1, 45 ,10)  # je fais réapparaitre la premiere image de la double-fleche
    toile.coords(double_fleche_sur_toile,15,10) # je fais réapparaitre la deuxieme image de la double-fleche
    bouton1.destroy() # on détruit le bouton1
    if mort==False: #si cupidon est encore en vie alors :
        if temps_de_jeu>=1: # si le temps de jeu est superieur ou egal a 1 :
            temps_de_jeu=temps_de_jeu-1 #on le diminue de 1
            toile.itemconfig(affiche_temps_de_jeu,text=" : "+str(temps_de_jeu) +" x") # on modifie le temps sur la toile
        if temps_de_jeu==1: #si le temps est egal a 1 alors:
            music_bonus.play(0) # on joue la music
    if temps_de_jeu==0: # si le temps est égal a 0 alors
        double_fleche=True #on dit que double fleche est disponible pour pouvoir tirer 2 fleche en meme temps
        bonus_disponible1(0) # j'appelle la fonction qui fait bouger le bonus en haut a droite

    toile.after(1000,tirer_2_sens_disponible) # on appelle la fonction pour qu'elle tourne en boucle et qu'elle soit appeler toute les secondes


def tirer_2_sens():
    '''fonction qui permet a cupidon de tirer dans les 2 sens'''
    global temps_de_jeu, direction,score , l_fleche , x_cupidon, y_cupidon # on prend les valeurs en global qui nous interresse
    if direction =='gauche': #si la touche espace est toucher on va faire tirer cupidon
         x_fleche=x_cupidon-20  # on definit les coordonées de la fleche
         y_fleche=y_cupidon-13
         l_fleche.append([toile.create_image((x_fleche, y_fleche), image =images_fleche[0]),x_fleche,y_fleche,direction,'visible']) # on ajoute les fleches à la fenêtre et on l'ajoute dans une liste
         tirer(0)  # on appel la fonction tirer
         direction='droite' # on definit le direction a droite
         x_fleche=x_cupidon+20   # on definit les coordonées de la fleche
         y_fleche=y_cupidon-13
         l_fleche.append([toile.create_image((x_fleche, y_fleche), image =images_fleche[1]),x_fleche,y_fleche,direction,'visible'])  # on ajoute les fleches à la fenêtre et on l'ajoute dans une liste
         tirer(0)  # on appel la fonction tirer
         direction='gauche' # on definit le direction a gauche
    if direction =='droite': #si la touche espace est toucher on va faire tirer cupidon
         x_fleche=x_cupidon+20   # on definit les coordonées de la fleche
         y_fleche=y_cupidon-13
         l_fleche.append([toile.create_image((x_fleche, y_fleche), image =images_fleche[1]),x_fleche,y_fleche,direction,'visible'])  # on ajoute les fleches à la fenêtre et on l'ajoute dans une liste
         tirer(0)  # on appel la fonction tirer
         direction='gauche' # on definit le direction a gauche
         x_fleche=x_cupidon-20  # on definit les coordonées de la fleche
         y_fleche=y_cupidon-13
         l_fleche.append([toile.create_image((x_fleche, y_fleche), image =images_fleche[0]),x_fleche,y_fleche,direction,'visible']) # on ajoute les fleches à la fenêtre et on l'ajoute dans une liste
         tirer(0)  # on appel la fonction tirer
         direction='droite' # on definit le direction a droite
    score=score+8 # on augmente le score de 8
    toile.itemconfig(affiche_score,text="score : "+str(score)) # on modifie le score sur la toile
    temps_de_jeu=20 # on remet le temps de jeu a 20 s

def fleche_destructive_disponible():
    '''fonction qui permet de regarder quand la focntion fleche destructive massive est disponible'''
    global direction, fleche_destructive,mort,temps_fleche_indestructible,music_bonus,fleche_indestructible_toile # on prend les valeurs en global qui nous interresse
    toile.coords(fleche_indestructible_toile,25,22) # je fais réapparaitre l'image de la petite fleche indestructible
    if mort==False: #si cupidon est encore en vie alors :
        if temps_fleche_indestructible>=1: # si le temps de jeu est superieur ou egal a 1 :
            temps_fleche_indestructible=temps_fleche_indestructible-1 # on eleve 1 a temps_fleche_indestructible pour diminuer le temps
            toile.itemconfig(affiche_temps_de_fleche_indestructible,text=" : "+str(temps_fleche_indestructible)+" c") # on modifie le temps sur la toile
        if temps_fleche_indestructible==1: #si le temps est egal a 1 alors:
            music_bonus.play(0) # je stop la musique
    if temps_fleche_indestructible == 0: # si le temps est égal a 0 alors
        fleche_destructive=True #on dit que la fleche destructive est disponible pour pouvoir la tirer
        bonus_disponible2(0)# j'appelle la fonction qui fait bouger le bonus en haut a droite
    fenetre.after(1000, fleche_destructive_disponible) # on appelle la fonction pour qu'elle tourne en boucle et qu'elle soit appeler toute les secondes





def fleche_destructive_massive():
    '''fonction qui envoie une fleche qui detruit tout les mechants jusqu'a ce qu'elle sorte de la fenetre'''
    global direction,l_fleche,x_cupidon,y_cupidon,temps_fleche_indestructible, score, affiche_score# on prend les valeurs en global qui nous interresse
    if direction =='gauche': #si la touche espace est toucher on va faire tirer cupidon
         x_fleche=x_cupidon-20  # on definit les coordonées de la fleche
         y_fleche=y_cupidon-13
         l_fleche.append([toile.create_image((x_fleche, y_fleche), image =images_fleches_indestructible[0]),x_fleche,y_fleche,direction,'undestructible']) # on ajoute les fleches à la fenêtre et on l'ajoute dans une liste
         tirer(0)  # on appel la fonction tirer
    if direction =='droite': #si la touche espace est toucher on va faire tirer cupidon
         x_fleche=x_cupidon+20   # on definit les coordonées de la fleche
         y_fleche=y_cupidon-13
         l_fleche.append([toile.create_image((x_fleche, y_fleche), image =images_fleches_indestructible[1]),x_fleche,y_fleche,direction,'undestructible'])  # on ajoute les fleches à la fenêtre et on l'ajoute dans une liste
         tirer(0)  # on appel la fonction tirer
    temps_fleche_indestructible=30 # on remet le temps de jeu a 30 s
    score=score+8 # on augmente le score de 8
    toile.itemconfig(affiche_score,text="score : "+str(score)) # on modifie le score sur la toile


def fusee_explosive():
    '''fonction qui lancera une fusee explosive et detruia tout les monstres a proximiter'''
    global mort,direction,score,affiche_scoreb,fusee_rouge,temps_fusee,music_bonus,fusee_sur_toile # on prend les valeurs en global qui nous interresse
    toile.coords(fusee_sur_toile,25,40) # je fais réapparaitre l'image de la petite fusée
    if mort==False: #si cupidon est encore en vie alors :
        if temps_fusee>=1: # si le temps de jeu est superieur ou egal a 1 :
            temps_fusee=temps_fusee-1 # on eleve 1 a temps_carapace pour diminuer le temps
            toile.itemconfig(affiche_temps_fusee,text=" : "+str(temps_fusee)+" v") # on modifie le temps sur la toile
        if temps_fusee==1: #si le temps est egal a 1 alors:
            music_bonus.play(0) # on joue la music
    if temps_fusee == 0: # si le temps est égal a 0 alors
        fusee_rouge=True #on dit que la fleche destructive est disponible pour pouvoir la tirer
        bonus_disponible0(0) # j'appelle la fonction qui fait bouger le bonus en haut a droite
    fenetre.after(1000, fusee_explosive) # on appelle la fonction pour qu'elle tourne en boucle et qu'elle soit appeler toute les secondes

def fusee_en_action():
    ''' fonction qui est appele pour tirer la fusee qui fera boum'''
    global direction,l_fleche,x_cupidon,y_cupidon,temps_fusee, score, affiche_score # on prend les valeurs en global qui nous interresse
    if direction =='gauche': #si la touche espace est toucher on va faire tirer cupidon
         x_fleche=x_cupidon-20  # on definit les coordonées de la fleche
         y_fleche=y_cupidon-13
         l_fleche.append([toile.create_image((x_fleche, y_fleche), image =image_fusée[0]),x_fleche,y_fleche,direction,'fusee']) # on ajoute les fleches à la fenêtre et on l'ajoute dans une liste
         tirer(0)  # on appel la fonction tirer
    if direction =='droite': #si la touche espace est toucher on va faire tirer cupidon
         x_fleche=x_cupidon+20   # on definit les coordonées de la fleche
         y_fleche=y_cupidon-13
         l_fleche.append([toile.create_image((x_fleche, y_fleche), image =image_fusée[1]),x_fleche,y_fleche,direction,'fusee'])  # on ajoute les fleches à la fenêtre et on l'ajoute dans une liste
         tirer(0)  # on appel la fonction tirer
    temps_fusee=35 # on remet le temps de jeu a 35 s
    score=score+8 # on augmente le score de 8
    toile.itemconfig(affiche_score,text="score : "+str(score)) # on modifie le score sur la toile



def carapace_rouge_temps():
    '''fonction qui changera le temps avant d'obtenir la carapace rouge'''
    global mort,direction,score,carapace_rouge,temps_carapce,music_bonus,carapace_rouge_sur_toile # on prend les valeurs en global qui nous interresse
    toile.coords(carapace_rouge_sur_toile,20,60) # je fais réapparaitre l'image de la petite carapace rouge
    if mort==False: #si cupidon est encore en vie alors :
        if temps_carapce>=1: # si le temps de jeu est superieur ou egal a 1 :
            temps_carapce=temps_carapce-1 # on eleve 1 a temps_carapace pour diminuer le temps
            toile.itemconfig(affiche_temps_carapace,text=" : "+str(temps_carapce)+" n") # on modifie le temps sur la toile
        if temps_carapce==1: #si le temps est egal a 1 alors:
            music_bonus.play(0) # on joue la music
    if temps_carapce == 0: # si le temps est égal a 0 alors
        carapace_rouge=True #on dit que la fleche destructive est disponible pour pouvoir la tirer
        bonus_disponible4(0)# j'appelle la fonction qui fait bouger le bonus en haut a droite

    fenetre.after(1000, carapace_rouge_temps) # on appelle la fonction pour qu'elle tourne en boucle et qu'elle soit appeler toute les secondes

def carapace_rouge_tire():
    '''fonction qui tirera une carapace rouge et qui detruira la moitier du nombre de vague qui tuera ceux qui sont les plus proches de cupidon'''
    global direction,x_cupidon,y_cupidon,temps_carapce,affiche_score,score,l_fleche,image_carapace_rouge # on prend les valeurs en global qui nous interresse
    if direction =='gauche': #si la touche espace est toucher on va faire tirer cupidon
         x_fleche=x_cupidon-20  # on definit les coordonées de la fleche
         y_fleche=y_cupidon-13
         l_fleche.append([toile.create_image((x_fleche, y_fleche), image =image_carapace_rouge[0]),x_fleche,y_fleche,direction,'carapace']) # on ajoute les fleches à la fenêtre et on l'ajoute dans une liste
    if direction =='droite': #si la touche espace est toucher on va faire tirer cupidon
         x_fleche=x_cupidon+20   # on definit les coordonées de la fleche
         y_fleche=y_cupidon-13
         l_fleche.append([toile.create_image((x_fleche, y_fleche), image =image_carapace_rouge[1]),x_fleche,y_fleche,direction,'carapace'])  # on ajoute les fleches à la fenêtre et on l'ajoute dans une liste
    temps_carapce=35 # on remet le temps de avant d'obtenir le bonus a 35 s
    score=score+8 # on augmente le score de 8
    toile.itemconfig(affiche_score,text="score : "+str(score)) # on modifie le score sur la toile

def carapace_rouge_avancer():
    '''fonction qui ferra avancer les carapaces rouges'''
    global l_mechant,l_fleche,image_carapace_rouge,mort,nombre_max_carapace,nombre_de_mechants_toucher_carapace,v # on prend les valeurs en global qui nous interresse
    if mort == False : # si cupidon est encore en vie
        if l_mechant!=[]: # si la liste des mechants est differentes de vides
            if l_fleche!=[]: # si la liste des fleches est differentes de vides
                for elmtt in l_fleche : #pour chaque element dans la liste
                    for elt in l_mechant: # pour chaque element dans la liste des mechants
                        if elt[4]=='alive': #si au moins 1 est en vie alors:
                                if elmtt[4]=='carapace': # si le fleche est une carapace
                                    if l_mechant[v][1] - 5 > elmtt[1]: # on compare chaque element au coordonee de cupidon et si x_fleche est superieur:
                                            elmtt[3]='gauche' # le sens est donc la gauche pour la carapaces
                                            elmtt[1]=elmtt[1]+7 #  sinon on rajoute 7 pixels
                                    elif l_mechant[v][1] + 5 < elmtt[1]: #  on compare chaque element au coordonee de cupidon et si x_fleche est inferieur:
                                        elmtt[3]='droite' # le sens est donc la droite pour la carapace
                                        elmtt[1]=elmtt[1]-7 #  sinon on rajoute 7 pixels
                                    if l_mechant[v][2] -5 > elmtt[2]:# on compare chaque element au coordonee de cupidon et si y_cupidon est superieur:
                                        elmtt[2]=elmtt[2]+5 # on augmente de 5 pixels les y des carapaces
                                    elif l_mechant[v][2] +5 < elmtt[2]:
                                        elmtt[2]=elmtt[2]-5 # on dimiue de 5 pixels les y des carapaces
                                    if elmtt[3]=='droite': # si le sens est la droite pour les carapaces alors
                                        toile.itemconfigure(elmtt[0], image=image_carapace_rouge[1]) # on modifie l'image de la carapace sur la toile
                                    else: # sinon
                                        toile.itemconfigure(elmtt[0], image=image_carapace_rouge[0]) # on modifie l'image de la carapace sur la toile
                                toile.coords(elmtt[0],elmtt[1],elmtt[2]) #on déplace la fleche sur la toile
                    if elmtt[4] == 'carapace' and nombre_de_mechants_toucher_carapace > int(nombre_max_carapace): # si la fleche est une carapace et que le nombre de mechants est superieur au nombre max que la carapace peut toucher
                        toile.delete(elmtt[0]) # on supprime la carapace de la toile
                        elmtt[4]='invisible' # on met les fleches en invisible
                        nombre_de_mechants_toucher_carapace=0 # on met le nombre de mechants toucher a 0
    toile.after(20, carapace_rouge_avancer) # on appelle la fonction pour qu'elle tourne en boucle



def bonus_disponible0(t):
    '''fonction qui va mettre les bonus disponible en mode clignotant'''
    global fusee_rouge,fusee_sur_toile # on prend les valeurs en global qui nous interresse
    if fusee_rouge ==True and t%2==0:  # si la fusee_rouge est vrai ainsi que si le t est paire:
        toile.coords(fusee_sur_toile,-50,0) # je deplace l'image de la petite fusée pour qu'elle sorte du champs et ne plus la voir
    if fusee_rouge ==True and t%2==1: # si la fusee_rouge est vrai ainsi que si le t est impaire:
        toile.coords(fusee_sur_toile,25,40) # je deplace l'image de la petite fusée pour qu'elle rentre dans le champs et donc la voir
    if fusee_rouge ==True : # si le bonus est disponible alors :
        toile.after(500,bonus_disponible0,t+1) # on appelle la fonction pour qu'elle tourne en boucle

def bonus_disponible1(t):
    '''fonction qui va mettre les bonus disponible en mode clignotant'''
    global double_fleche,double_fleche_sur_toile_1 # on prend les valeurs en global qui nous interresse
    if double_fleche ==True and t%2==0: # si la double_fleche est vrai ainsi que si le t est paire:
        toile.coords(double_fleche_sur_toile_1,-50,0) # je deplace l'image des doubles-fleches pour qu'elle sorte du champs et ne plus la voir
        toile.coords(double_fleche_sur_toile,-50,0)
    if double_fleche ==True and t%2==1: # si la double_fleche est vrai ainsi que si le t est impaire:
        toile.coords(double_fleche_sur_toile_1, 45 ,10) # je deplace l'image de la double_fleche pour qu'elle rentre dans le champs et donc la voir
        toile.coords(double_fleche_sur_toile,15,10)
    if double_fleche==True : # si le bonus est disponible alors :
        toile.after(500,bonus_disponible1,t+1) # on appelle la fonction pour qu'elle tourne en boucle

def bonus_disponible2(t):
    '''fonction qui va mettre les bonus disponible en mode clignotant'''
    global fleche_destructive,fleche_destructive_toile # on prend les valeurs en global qui nous interresse
    if fleche_destructive == True and t%2==0: # si la fleche_destructive est vrai ainsi que si le t est paire:
        toile.coords(fleche_indestructible_toile,-50,0) # je deplace l'image de la petite fleche indestructible pour qu'elle sorte du champs et ne plus la voir
    if fleche_destructive == True and t%2==1: # si la fleche_destructive est vrai ainsi que si le t est impaire:
        toile.coords(fleche_indestructible_toile,25,22) # je deplace l'image de la fleche_destructive pour qu'elle rentre dans le champs et donc la voir
    if fleche_destructive ==True : # si le bonus est disponible alors :
        toile.after(500,bonus_disponible2,t+1) # on appelle la fonction pour qu'elle tourne en boucle

def bonus_disponible3(t):
    '''fonction qui va mettre les bonus disponible en mode clignotant'''
    global bouclier_action,bouclier_sur_toile # on prend les valeurs en global qui nous interresse
    if bouclier_action == True and t%2==0: # si la bouclier_action est vrai ainsi que si le t est paire:
        toile.coords(bouclier_sur_toile,-50,0) # je deplace l'image du bouclier pour qu'elle sorte du champs et ne plus la voir
    if bouclier_action == True and t%2==1: # si la bouclier_action est vrai ainsi que si le t est impaire:
        toile.coords(bouclier_sur_toile,120,25) # je deplace l'image de la bouclier_action pour qu'elle rentre dans le champs et donc la voir
    if bouclier_action==True :
        toile.after(500,bonus_disponible3,t+1) # on appelle la fonction pour qu'elle tourne en boucle

def bonus_disponible4(t):
    '''fonction qui va mettre les bonus disponible en mode clignotant'''
    global carapace_rouge,carapace_rouge_sur_toile # on prend les valeurs en global qui nous interresse
    if carapace_rouge == True and t%2==0: # si la carapace_rouge est vrai ainsi que si le t est paire:
        toile.coords(carapace_rouge_sur_toile,-50,0) # je deplace l'image de la carapace rouge pour qu'elle sorte du champs et ne plus la voir
    if carapace_rouge == True and t%2==1: # si la carapace_rouge est vrai ainsi que si le t est impaire:
        toile.coords(carapace_rouge_sur_toile,20,60) # je deplace l'image de la carapace_rouge pour qu'elle rentre dans le champs et donc la voir
    if carapace_rouge == True: # si le bonus est disponible alors :
        toile.after(500,bonus_disponible4,t+1) # on appelle la fonction pour qu'elle tourne en boucle

def bonus_disponible5(t):
    '''fonction qui va mettre les bonus disponible en mode clignotant'''
    global mine_sur_toile,mine_vf # on prend les valeurs en global qui nous interresse
    if mine_vf == True and t%2==0: # si la carapace_rouge est vrai ainsi que si le t est paire:
        toile.coords(mine_sur_toile,-50,0) # je deplace l'image de la mine_vf  pour qu'elle sorte du champs et ne plus la voir
    if mine_vf == True and t%2==1: # si la mine_vf est vrai ainsi que si le t est impaire:
        toile.coords(mine_sur_toile,105,55) # je deplace l'image de la mine pour qu'elle rentre dans le champs et donc la voir
    if mine_vf == True: # si le bonus est disponible alors :
        toile.after(500,bonus_disponible5,t+1) # on appelle la fonction pour qu'elle tourne en boucle





def mine_sur_la_toile(t):
    '''fonction qui fera apparaitre une mine de maniere sur la toile'''
    global l_mine,x_cupidon,y_cupidon,temps_afficher_mine,score,affiche_score # on prend les valeurs en global qui nous interresse
    x_mine=x_cupidon # je prend des valeurs de cupidon pour poser la mine
    y_mine=y_cupidon # je prend des valeurs de cupidon pour poser la mine
    l_mine.append([toile.create_image(x_mine,y_mine, image =image_mine[0]),x_mine,y_mine,'activer'])  # je créer l'image sur la toile de la mine
    temps_afficher_mine=25 # on remet le temps de avant d'obtenir le bonus a 25 s
    score=score+8 # on augmente le score de 8
    toile.itemconfig(affiche_score,text="score : "+str(score)) # on modifie le score sur la toile



def temps_pour_la_mine():
    '''fonction qui affichera le temps avant que cupidon posera la mine'''
    global mort,direction,score,mine_vf,temps_afficher_mine,music_bonus,mine_sur_toile,affiche_temps_mine# on prend les valeurs en global qui nous interresse
    toile.coords(mine_sur_toile,105,55) # je fais réapparaitre l'image de la petite carapace rouge
    if mort==False: #si cupidon est encore en vie alors :
        if temps_afficher_mine>=1: # si le temps de jeu est superieur ou egal a 1 :
            temps_afficher_mine=temps_afficher_mine-1 # on eleve 1 a temps_carapace pour diminuer le temps
            toile.itemconfig(affiche_temps_mine,text=" : "+str(temps_afficher_mine)+" w") # on modifie le temps sur la toile
        if temps_afficher_mine==1: #si le temps est egal a 1 alors:
            music_bonus.play(0) # on joue la musique
    if temps_afficher_mine == 0: # si le temps est égal a 0 alors
        mine_vf=True #on dit que la fleche destructive est disponible pour pouvoir la tirer
        bonus_disponible5(0) # j'appelle la fonction qui fait bouger le bonus en haut a droite
    fenetre.after(1000, temps_pour_la_mine) # on appelle la fonction pour qu'elle tourne en boucle et qu'elle soit appeler toute les secondes






def image_des_explosion(t):
    '''fonction qui affichera les images des explosions'''
    global l_fleche,l_mechant,affiche_score,score,mort,direction,l_explosion,l_mine # on prend les valeurs en global qui nous interresse
    for elmt in l_fleche : # pour chaque element dans la liste des fleches
        if elmt[4]=='fusee': # si element de 4 est = a fusee alors
            x_explosion=elmt[1] # on définit les coordonnée de l'explosion grace au coordonnéée de la fusee qui explose
            y_explosion=elmt[2]
    for emt in l_mine: # pour chaque element dans la liste des mines
        if emt[3]=='bom': # si la mine est activer
            x_explosion=emt[1] # on définit les coordonnée de l'explosion grace au coordonnéée de la fusee qui explose
            y_explosion=emt[2]

    if t==0 : # si t vaut 0 alors
                    l_explosion.append([toile.create_image((x_explosion, y_explosion),image =images_explosion[0]),'explose']) # on ajoute a la liste l'explosion avec ces images et on la met en explose
    for ellmmtt in l_explosion: # pour chaque element dans la liste explosion on va passer les images de l'explosion 1 par 1
        if t==1: # si t vaut 1 alors :
            monstre_meurt_explosion() # on appel a la fonction monstre_meurt_explosion pour savoir si il y a pas de monstre dans l'explosion
            toile.itemconfigure(ellmmtt[0], image=images_explosion[1]) # on modifie l'image de l'explosion sur la toile
            ellmmtt[1]='neutre'  #on passe l'explosion en neutre
        if t==2: # si t vaut 2 alors :
            toile.itemconfigure(ellmmtt[0], image=images_explosion[2]) # on modifie l'image de l'explosion sur la toile
        if t==3: # si t vaut 3 alors :
            toile.itemconfigure(ellmmtt[0], image=images_explosion[3]) # on modifie l'image de l'explosion sur la toile
        if t==4: # si t vaut 4 alors :
            toile.itemconfigure(ellmmtt[0], image=images_explosion[4]) # on modifie l'image de l'explosion sur la toile
        if t==5: # si t vaut 5 alors :
            toile.itemconfigure(ellmmtt[0], image=images_explosion[5]) # on modifie l'image de l'explosion sur la toile
        if t==6 : # si t vaut 6 alors :
            toile.delete(ellmmtt[0]) # on supprime de la toile la derniere image de l'explosion
    t=t+1 # on incrémente le compteur de récursivité
    fenetre.after(70, image_des_explosion,t) # on appelle la fonction pour qu'elle tourne en boucle


def monstre_meurt_explosion():
    '''fonction qui tuera les mechants dans le rayon d'explosion de la carapace ou de la mine'''
    global l_explosion,l_mechant,mort,score,affiche_score,l_fleche,l_mine  # on prend les valeurs en global qui nous interresse
    for elmt in l_fleche: # pour chaque element dans la liste l_fleche on fait :
            for elmtt in l_mechant: # pour chaque element dans la liste de mechants on fait :
                for elt in l_explosion : # pour chaque element dans la liste des explosion on fait :
                    if abs (elmtt[1]-elmt[1])< 80 and abs (elmtt[2]-elmt[2])< 80 and elmtt[4]=='alive' and elt[1]=='explose': # on regarde si dans l'explosion il y a des monstres et si les monstres sont en vie et si l'explosion est active 'explose'
                        elmtt[4]='dead' #le monstre devient mort
                        del (elt) # on supprime l'element de la liste des explosions
                        if mort == False :  #si cupidon est encore en vie alors :
                            score+=10 # on augmente le score de 10 pour avoir tuer un monstre
                            toile.itemconfig(affiche_score,text="score : "+str(score)) # on modifie le score sur la toile
    for emt in l_mine: # pour chaque element dans la liste des mines
        for elmtti in l_mechant: # pour chaque element dans la liste de mechants on fait :
                for elti in l_explosion : # pour chaque element dans la liste des explosion on fait :
                    if abs (elmtti[1]-emt[1])< 80 and abs (elmtti[2]-emt[2])< 80 and elmtti[4]=='alive' and elti[1]=='explose': # on regarde si dans l'explosion il y a des monstres et si les monstres sont en vie et si l'explosion est active 'explose'
                        elmtti[4]='dead' #le monstre devient mort
                        del (elti) # on supprime l'element de la liste des explosions
                        if mort == False :  #si cupidon est encore en vie alors :
                            score+=10 # on augmente le score de 10 pour avoir tuer un monstre
                            toile.itemconfig(affiche_score,text="score : "+str(score)) # on modifie le score sur la toile

    toile.after (5,monstre_meurt_explosion)  # on appelle la fonction pour qu'elle tourne en boucle


def fleche_toucher_mechant ():
    '''fonction qui regarde si la fleche rentre en collision avec le mechant'''
    global l_fleche,l_mechant,affiche_score,score,mort,time_shield,mort_mechant,flecher_dans_mechant,n,nombre_de_mechants_toucher_carapace ,l_mine # on prend les valeurs en global qui nous interresse
    for elmtt in l_fleche: # pour chaque element dans la liste l_fleche on fait :
        if elmtt[1]>1050 and (elmtt[4]=='visible' or elmtt[4]=='undestructible' or elmtt[4]=='fusee'):   # si la fleche sort de la fenetre tout en etant visible alors
            elmtt[4]='hors_jeu'  # les fleches devienne hors jeu
            score=score-2 # on diminue le score de 2 points
            toile.itemconfig(affiche_score,text="score : "+str(score))  # on modifie le score sur la toile
        if elmtt[1]<-50 and elmtt[4]=='visible': # si la fleche sort de la fenetre tout en etant visible alors
            elmtt[4]='hors_jeu'  # les fleches devienne hors jeu
            score=score-2 # on diminue le score de 2 points
            toile.itemconfig(affiche_score,text="score : "+str(score)) # on modifie le score sur la toile
        for elmt in l_mechant:  # pour chaque element dans la liste de mechants on fait :
            if abs (elmtt[1]-elmt[1])< 25 and abs (elmtt[2]-elmt[2])< 32 and elmt[4]=='alive' and elmtt[4]=='visible': # on regarde si les fleches rentre en collision avec le monstre et si les fleches sont visible et si les monstres sont en vie
                flecher_dans_mechant.play(0) # je joue le musique flecher_dans_mechant
                toile.delete(elmtt[0]) # on supprime la fleche de la toile
                elmt[4]='dead' #le monstre devient mort
                mort_mechant.play(0) # on joue le son de mort des mechants quand ils sont touchés
                if mort==False: # si cupidon est encore en vie
                    score+=10 # on augmente le score de 10 pour avoir tuer un monstre
                    toile.itemconfig(affiche_score,text="score : "+str(score)) # on modifie le score sur la toile
                elmtt[4]='invisible' # on met les felches en inviible
                break # on arrete
            if abs (elmtt[1]-elmt[1])< 25 and abs (elmtt[2]-elmt[2])< 32 and elmt[4]=='alive' and elmtt[4]=='undestructible':   # on regarde si les fleches rentre en collision avec le monstre et si les fleches sont visible et si les monstres sont en mode indestructible
                mort_mechant.play(0) # on joue le son de mort des mechants quand ils sont touchés
                elmt[4]='dead' #le monstre devient mort
                if mort==False: # si cupidon est encore en vie
                    score+=10 # on augmente le score de 10 pour avoir tuer un monstre
                    toile.itemconfig(affiche_score,text="score : "+str(score)) # on modifie le score sur la toile
            if abs (elmtt[1]-elmt[1])< 50 and abs (elmtt[2]-elmt[2])< 50 and elmt[4]=='alive' and elmtt[4]=='fusee':   # on regarde si les fleches rentre en collision avec le monstre et si les fleches sont des fusée
                mort_mechant.play(0) # on joue le son de mort des mechants quand ils sont touchés
                image_des_explosion(0)# on appel la fonction pour mettre les images des explosion
                bruit_explosion.play(0) # on appel la fonction pour mettre les images des explosion
                elmt[4]='dead' #le monstre devient mort
                elmtt[4]='plus_fusee' # on dit que la fusée n'existe plus
                score+=10 # on augmente le score de 10 pour avoir tuer un monstre
                toile.itemconfig(affiche_score,text="score : "+str(score)) # on modifie le score sur la toile
                toile.delete(elmtt[0]) # on supprime la fusee de la toile
                elmtt[4]='invisible' # on met les felches en invisible
            if abs (elmtt[1]-elmt[1])< 50 and abs (elmtt[2]-elmt[2])< 50 and elmt[4]=='alive' and elmtt[4]=='carapace':   # on regarde si les fleches rentre en collision avec le monstre et si les fleches sont des carapaces et si les monstres sont en mode vie
                mort_mechant.play(0) # on joue le son de mort des mechants quand ils sont touchés
                elmt[4]='dead' #le monstre devient mort
                nombre_de_mechants_toucher_carapace+=1 # j'augmente de 1 le nombre de mechants mort par la carapace
                score+=10 # on augmente le score de 10 pour avoir tuer un monstre
                toile.itemconfig(affiche_score,text="score : "+str(score)) # on modifie le score sur la toile
    for elmttt in l_mechant: # pour chaque element dans la liste de mechants on fait :
        for eltz in l_mine : # pour chaque element dans la liste des mine on fait :
            if abs (elmttt[1]-eltz[1])< 45 and abs (elmttt[2]-eltz[2])< 55 and elmttt[4]=='alive' and eltz[3]=='activer': # on regarde si dans la mine il y a des monstres et si les monstres sont en vie et si la mine est active 'activer'
                mort_mechant.play(0) # on joue le son de mort des mechants quand ils sont touchés
                eltz[3]='bom' # je rend la mine inaufensif
                image_des_explosion(0)# on appel la fonction pour mettre les images des explosion
                bruit_explosion.play(0) # on appel la fonction pour mettre les images des explosion
                elmttt[4]='dead' #le monstre devient mort
                score+=10 # on augmente le score de 10 pour avoir tuer un monstre
                toile.itemconfig(affiche_score,text="score : "+str(score)) # on modifie le score sur la toile
                eltz[3]='inutile' # je rend la mine inaufensif
                toile.delete(eltz[0]) # je supprime la mine de la toile
                del (eltz) # on supprime l'element de la liste des mine


    for elt in l_mechant: # pour chaque element dans la liste l_mechant
        if l_mechant!=[] and elt[4]=='disparut': # si la liste de mechnat est different de vide et que l'element de 4 est disparut alors:
            del (elt) #on supprime le mechant de la liste

    for elllt in l_fleche : # pour chaque element dans la liste l_fleche
        if l_fleche!=[] and (elllt[1]<-51 or elllt[1]>1051) :  # si la liste de fleche comporte des fleches et si la fleche sort de la toile alors:
            del (elllt) #on supprime la fleche
    toile.after(5,fleche_toucher_mechant) # on rapelle en boucle la fonction (récursivité)






def pop_mechant():
    '''fonction qui fait apparaitre les mechant qui vont attaquer cupidon'''
    global sens, images_mechant,l_mechant,mort,temps,n # on prend les valeurs en global qui nous interresse
    if mort==False: #si cupidon est encore en vie alors :
        pop=randint(0,3) # on prend un nombre aléatoire entre 0 et 3
        for i in range (n-1): # je creer des vague de monstre
            if pop==0: #si le nombre est 0 alors:
                x_mechant=-40 # on fait apparaitre le mechant en dehors de la toile a gauche
                y_mechant=randint(0,600) # et on le fait apparaitre avec un ordonnee aléatoire
                sens='droite' # on definit le sens du mechant a droite
                l_mechant.append([toile.create_image((x_mechant,y_mechant),image=images_mechant[0]),x_mechant,y_mechant,sens,'alive',0]) # on ajoute les mechants à la fenêtre et on l'ajoute dans une liste
            if pop==1: #si le nombre est 1 alors:
                x_mechant=1040 # on fait apparaitre le mechant en dehors de la toile a droite
                y_mechant=randint(0,600) # et on le fait apparaitre avec un ordonnee aléatoire
                sens='gauche' # on definit le sens du mechant a droite
                l_mechant.append([toile.create_image((x_mechant,y_mechant),image=images_mechant[0]),x_mechant,y_mechant,sens,'alive',0]) # on ajoute les mechants à la fenêtre et on l'ajoute dans une liste
            if pop==2: #si le nombre est 2 alors:
                x_mechant=randint(0,1000) # on le fait apparaitre avec un abscisse aléatoire
                y_mechant=-40 # on fait apparaitre le mechant en dehors de la toile en haut
                sens='droite' # on definit le sens du mechant a droite
                l_mechant.append([toile.create_image((x_mechant,y_mechant),image=images_mechant[0]),x_mechant,y_mechant,sens,'alive',0]) # on ajoute les mechants à la fenêtre et on l'ajoute dans une liste
            if pop==3: #si le nombre est 3 alors:
                x_mechant=randint(0,1000) # on le fait apparaitre avec un abscisse aléatoire
                y_mechant=640 # on fait apparaitre le mechant en dehors de la toile en bas
                sens='droite' # on definit le sens du mechant a droite
                l_mechant.append([toile.create_image((x_mechant,y_mechant),image=images_mechant[0]),x_mechant,y_mechant,sens,'alive',0]) # on ajoute les mechants à la fenêtre et on l'ajoute dans une liste
        if temps > 1000: # si le temps est supérieur a 1000 alors:
            temps=temps-100 # on enleve 100 au temps de sponne des monstres
    toile.after (temps, pop_mechant)  # on rapelle en boucle la fonction (récursivité)

def vague_de_monstre():
    '''fonction qui créer des differents vague de monstres'''
    global n,texte,nombre_max_carapace # on prend les valeurs en global qui nous interresse
    if n>=2: # si la vague est superieur ou égal a 2
        toile.itemconfig(texte,text="Vague numéro "+str(n)+" !") # on modie la vague sur la toile
    n=n+1 # on augmente de 1 n
    nombre_max_carapace+=0.5 # j'augmente de 0,5 pour que la carapce attaque le nombre de monstres diviser par 2 et quand c impaire c 1 de plus

def temps_vague_de_monstre():
    '''fonction qui va permettre de gerer le temps des vagues de monstres'''
    global vague_de_monstre_temps,mort # on prend les valeurs en global qui nous interresse
    if mort ==False : # si la mort est faux
        if vague_de_monstre_temps%16==0: #si le resultat de la vague_de_monstre_temps diviser par 16 vaut 0 alors
            vague_de_monstre() # j'appelle la fonction vague_de_monstre
            vague_de_monstre_temps=1 #je remet la vague_de_monstre_temps a 1
        else : # sinon
            vague_de_monstre_temps+=1 #j'augmente de 1 la vague_de_monstre_temps
    toile.after(1000,temps_vague_de_monstre) # on rapelle en boucle la fonction (récursivité) toute les secondes




def deplacement_mechant():
    '''fonction qui deplace le mechant en direction de cupidon pour le manger'''
    global x_cupidon,y_cupidon, l_mechant,t,mort,time_shield,health,v # on prend les valeurs en global qui nous interresse
    for elmt in l_mechant:# pour chaque element dans la liste l_mechant on fait :
        if elmt[4]=='alive'and mort ==False: #si le mechnat est en vie et si cupidon est encore en vie alors :
            if time_shield<=0 or sqrt((x_cupidon-elmt[1])**2+(y_cupidon-elmt[2])**2)>=80:#verifie si les monstres collent le bouclier ou pas (si time_shield et inferieur a 0, il n'y a pas de bouclier
                if x_cupidon - 5 > elmt[1]: # on compare chaque element au coordonee de cupidon et si x_cupidon est superieur:
                    elmt[3]='gauche' # le sens est donc la gauche pour le mechant
                    elmt[1]=elmt[1]+5 # et on augmente de 5 pixels les x des mechants
                elif x_cupidon + 5 < elmt[1]: # si la position de cupidon +5 est inferieur au x du mechant alors :
                    elmt[1]=elmt[1]-5  #sinon on diminue de 5 pixels les x des mechants
                    elmt[3]='droite' # le sens est donc la droite pour le mechant
                if y_cupidon -5 > elmt[2]:# on compare chaque element au coordonee de cupidon et si y_cupidon est superieur:
                    elmt[2]=elmt[2]+5 # on augmente de 5 pixels les y des mechants
                elif y_cupidon +5 < elmt[2]:
                    elmt[2]=elmt[2]-5 # on dimiue de 5 pixels les y des mechants
                if abs(x_cupidon-elmt[1])<48 and abs(y_cupidon-elmt[2])<53:   #si un mechant touche le cupidon alors le joueur a perdu une vie
                        vie()#diminue le nombre de vie du cupidon
                        if health>0: # si la vie de cupidon est superieur a 0 :
                            sons_mario_toucher(0) # on met le son de mario qui est toucher
            toile.coords(elmt[0],elmt[1],elmt[2])  # on déplace les images des mechants sur la toile
        if elmt[4]=='dead': # si le mechant est mort alors
            if elmt[3]=='gauche' and elmt[5]<6: # si le mechant est de direction gauche et de recursivite inferieur a 6
                toile.itemconfigure(elmt[0], image=images_mechant[4+elmt[5]] ) # on change son image et il prend les images de mort
                elmt[5]+=1 # on augmente leur recursivite pour qu'ils changent d'image
            if  elmt[3] =='droite' and elmt[5]<6: # si le mechant est de direction droite et de recursivite inferieur a 6
                toile.itemconfigure(elmt[0], image=images_mechant[13+elmt[5]] ) # on change son image et il prend les images de mort
                elmt[5]+=1 # on augmente leur recursivite pour qu'ils changent d'image
            if elmt[5]==6: # quand leur recursivite vaut 6 on fait :
                toile.delete(elmt[0]) # on les supprime de la toile
                elmt[4]='disparut' # on met le monstre en mode disparut pour pouvoir de supprimer de la liste
                v+=1 # augmente de 1 v pour que la carapace rouge attaque le mechants d'après
    toile.after(100 , deplacement_mechant)  # on rapelle en boucle la fonction (récursivité)


def battement_aille_mechant (t):
    '''fonction qui va faire battre les ailles des mechants '''
    global l_mechant  # on prend les valeurs en global qui nous interresse
    if l_mechant!=[]: #si la liste des mechants est differente de vide alors :
        for elmt in l_mechant: # pour chaque element dans la liste l_mechant on fait :
            if elmt[4]=='alive': # si le monstre est envie alors :
                if elmt[3]=="droite" : # on regarde si le sens du mechant est la droite ou non et si c'est la droite on fait:
                        toile.itemconfigure(elmt[0], image=images_mechant[t%4+10] ) # on ajoute l'image du mechant avec le sens droite
                if elmt[3] == "gauche":# on regarde si le sens du mechant est la gauche ou non et si c'est la gauche on fait:
                        toile.itemconfigure(elmt[0], image=images_mechant[t%4] ) # on ajoute l'image du mechant avec le sens gauche
        t=t+1  # on incrémente le compteur de récursivité
    fenetre.after(100,battement_aille_mechant,t) # on rapelle en boucle la fonction (récursivité)






def aide_des_bonus():
    '''fonction qui va ouvrir une fenetre pour aider avec les bonus'''
    global deja_jouer,affichage_de_pause,bouton4,bouton3,in_game,bouton_quitter_aide,bouton1,aide,image_bonus0,image_bonus1,image_bonus2,image_bonus3,image_bonus4,image_bonus5,image_bonus6,texte_bonus1,texte_bonus2,texte_bonus3,texte_bonus4,texte_bonus5,texte_bonus6,texte_bonus_1,texte_bonus_2,texte_bonus_3,texte_bonus_4,texte_bonus_5,texte_bonus_6, bouton_aide,affichage_daide,image_fusée1,image_bouclier_1,image_mine1,image_carapace_rouge1,images_fleches_toile,images_fleches_indestructible_1,mot_de_depart,mot_de_depart2,mot_de_depart3,mot_de_depart4,cuddi,photo_profile,parametre,affichage_ancien_score # on prend les valeurs en global qui nous interresse
    toile.delete(mot_de_depart2,mot_de_depart,mot_de_depart4,cuddi,photo_profile,parametre) # je supprime toute les images et les textes de l'acceuil qui nous seront plus utiles
    toile.itemconfig(affichage_ancien_score, text=' ') # je modifie le meuilleur score
    toile.itemconfig(mot_de_depart3,text='') # je modifie le mot de depart numero 3 en le rendant vide
    bouton_aide.destroy() #je detruit le bouton aide
    aide=True #je dit que je suis dans le menu aide
    if deja_jouer ==False:# si j'ai jamais lancer de parti :
        bouton1.destroy() # je detruit l bonus n°1
    elif deja_jouer==True : # si j'ai deja lancer une parti
        bouton4.destroy() #je detruit le bouton numero 4
    image_bonus0=toile.create_image(70,50 , image=images_fleches_toile[0]) # je créer les 6 different bonus sur le toile pour pouvoir expliquer a quoi ils servent
    image_bonus1=toile.create_image(100,50 , image=images_fleches_toile[1])
    image_bonus2=toile.create_image(70,250, image=images_fleches_indestructible_1[0])
    image_bonus3=toile.create_image(65,450, image=image_fusée1[0])
    image_bonus4=toile.create_image(565,50, image=image_carapace_rouge1[0])
    image_bonus5=toile.create_image(560,250, image=image_mine1[0])
    image_bonus6=toile.create_image(570,450, image=image_bouclier_1[0])
    texte_bonus1=toile.create_text(310,50,text='Ce bonus est le bonus double flèche il permet de tirer 2 fleches en '+'\n'+ 'même temps en appuyant sur la touche X quand celui-ci clignotera') # je créer 6 different textes expliquand a quoi servent chaque bonus avec des saut a la ligne
    texte_bonus2 =toile.create_text(320,250,text='Ce bonus est le bonus fleche indestructible il permet de tirer une fleches qui '+'\n'+ ' ne se détruit pas en appuyant sur la touche C quand celui-ci clignotera')
    texte_bonus3 =toile.create_text(320,450,text='Ce bonus est le bonus flèche fusée il permet de tirer 1 fusée qui va exploser au '+'\n'+ ' contact du premier mechants en appuyant sur la touche V quand celui-ci clignotera')
    texte_bonus4=toile.create_text(790,50,text='Ce bonus est le bonus carapace il permet de tirer 1 carapace qui va tuer '+'\n'+ 'les plus vieux monstres, la carapace en tuera la moitier du nombre de la '+'\n'+ 'vague actuelle en appuyant sur la touche N quand celui-ci clignotera')
    texte_bonus5=toile.create_text(790,250,text="Ce bonus est le bonus mine il permet de poser 1 mine aérienne et celle-ci "+'\n'+ " va d'ailleur exploser quand on mechant sera assez proches pour la déclencher "+'\n'+ " c'est en appuyant sur la touche W quand le bonus-ci clignotera qu'on l'active")
    texte_bonus6=toile.create_text(800,450,text="Ce bonus est le bonus bouclier il permet d'avoir un bouclier autour de "+'\n'+ 'cupidon pendant 6s en appuyant sur la touche B quand celui-ci clignotera')
    texte_bonus_1 =toile.create_text(123,49,text='=') # je créer un texte qui se place juste devant chaque image des different bonus et met un egal
    texte_bonus_2 =toile.create_text(109,248,text='=')
    texte_bonus_3=toile.create_text(90,448,text='=')
    texte_bonus_4=toile.create_text(587,50,text='=')
    texte_bonus_5=toile.create_text(578,250,text='=')
    texte_bonus_6=toile.create_text(594,450,text='=')
    if in_game==True:
        toile.itemconfigure(affichage_de_pause, image=image_fond[2])
        bouton3.destroy()
        bouton_quitter_aide =tk.Button(fenetre, text='QUITTER',command=lambda:(jeu_reprend2())) # je créer le bouton pour pouvoir quitter le menu d'aide
        bouton_quitter_aide.pack() # on ajoute le bouton a la toile
    else:
        bouton_quitter_aide =tk.Button(fenetre, text='QUITTER',command=lambda:(page_d_acceuil())) # je créer le bouton pour pouvoir quitter le menu d'aide
        bouton_quitter_aide.pack() # on ajoute le bouton a la toile





def recommence_la_partie():
    '''fonction qui va faire en sorte que quand on appuye dessus la partie recmmence'''
    global health,deja_jouer,bouton_aide,new_player,tableau,restard,bouton,numero_joueur,nom_utilisateur,bouton4,x_cupidon,page_d_acceuil,y_cupidon,ancien_score,horaire,l_mine,mort,t,fleche_indestructible_toile,mine_sur_toile,carapace_rouge_sur_toile,bouclier_sur_toile,double_fleche_sur_toile_1,double_fleche_sur_toile,health_bar,fusee_sur_toile,affiche_temps_bouclier,temps_en_haut,game_over,affiche_temps_mine,affiche_temps_carapace,affiche_temps_fusee,texte,affiche_temps_de_fleche_indestructible,affiche_temps_de_jeu,affiche_score,temps_de_partie_fin,score_de_fin,temps_reprendre_jeu,affichage_ancien_score,y,hit,temps_carapce,nombre_max_carapace,mine_vf,v,carapace_rouge,nombre_de_mechants_toucher_carapace,time_shield,temps,temps_afficher_mine,temps_bouclier,bouclier_action,bouton_restard,n,double_fleche,fusee_rouge,temps_de_jeu,score,fleche_destructive,temps_fleche_indestructible,action,sens,temps_fusee,l_mechant,l_fleche,l_explosion # on prend les valeurs en global qui nous interresse
    musique_pour_chargement() # j'appelle la fonction qui lancera la musique de la page d'acceuil
    bouton_aide.destroy() # je detruit le bouton aide
    bouton_aide = tk.Button(fenetre, text='AIDE', command =lambda: ( aide_des_bonus())) # on crée un bouton pour aider le joueur avec les bonus
    bouton_aide.pack() # on ajoute le bouton a la toile
    bouton_restard.destroy() # je detruis le bouton qui permet de restard la partie
    bouton4 = tk.Button(fenetre, text='RESTART', command =lambda: ( debut_s_restard() )) # on crée un bouton pour "restard" et pour relancer le jeu
    bouton4.pack() # on ajoute le bouton a la toile
    deja_jouer=True # je dis que j'ai deja jouer
    bouton.destroy() # je detruit le bouton
    toile.delete(game_over,fleche_indestructible_toile,mine_sur_toile,carapace_rouge_sur_toile,bouclier_sur_toile,double_fleche_sur_toile,double_fleche_sur_toile_1,fusee_sur_toile,health_bar,temps_en_haut,affiche_temps_bouclier,temps_de_partie_fin,score_de_fin,affiche_temps_carapace,affiche_temps_mine,affiche_score,texte,affiche_temps_fusee,affiche_temps_de_jeu,affiche_temps_de_fleche_indestructible,temps_reprendre_jeu) # je supprime toute les images et les textes de l'acceuil qui nous seront plus utiles
    page_d_acceuil() # j'appelle la fonction page d'acceuil
    if restard==False: # si j'appelle un nom qui est deja enregistrer :
        if int(ancien_score)<int(score): # si l'ancien score est inferieur au nouveau
            restard =True #je dit que restard est vrai
            ancien_score=score # alors l'ancien score devient le nouveau
            toile.itemconfig(affichage_ancien_score, text='Best score = '+str(ancien_score)) # je modifie le meuilleur score
            with open("recherche.csv","r") as f: # j'ouvre le fichier avec tout les noms et score
                lines = f.readlines() # je regarde chaque ligne
                ptr=1 # j'augmente de 1 a ptr
                with open("recherche.csv","w") as outpute: #j'ouvre le fichier et je vais le modifier
                    for line in lines : # pour chaque ligne dans le fichier lines
                        if ptr != (numero_joueur+1): # si ptr est diferent du numero de joueur alors :
                            outpute.write(line) # j'ecrit la ligne dans le nouveau fichier
                        ptr+=1 # j'augmente de 1 a ptr
            with open ("recherche.csv","a",newline="", encoding='utf-8') as csvfile : # j'ouvre le fichier recherche et je l'appelle csvfile et je met a pour rajouter a la fi du texte les nouveau nom si il y en a
                if len(tableau)==numero_joueur+1  : # si la longueur du tableau est egal au numero du joueur + 1 alors
                    csvfile.write(nom_utilisateur+","+str(ancien_score)) # j'ajoute le nom au fichier a la fin sans un saut de ligne
                else : # sinon
                    csvfile.write("\n"+nom_utilisateur+","+str(ancien_score)) # j'ajoute le nom au fichier a la fin avec un saut de ligne
    elif new_player==True: # sinon si c'est un nouveau joueur
        if int(ancien_score)<int(score): # si l'ancien score est inferieur au nouveau
            ancien_score=score # alors l'ancien score devient le nouveau
            toile.itemconfig(affichage_ancien_score, text='Best score = '+str(ancien_score)) # je modifie le meuilleur score
            with open("recherche.csv","r") as f: # j'ouvre le fichier avec tout les noms et score
                lines = f.readlines() # je regarde chaque ligne
                ptr=1 # j'augmente de 1 a ptr
                with open("recherche.csv","w") as outpute: #j'ouvre le fichier et je vais le modifier
                    for line in lines : # pour chaque ligne dans le fichier lines
                        if ptr != (len(tableau)+1): # si ptr est diferent du numero de joueur alors :
                            outpute.write(line) # j'ecrit la ligne dans le nouveau fichier
                        ptr+=1 # j'augmente de 1 a ptr
            with open ("recherche.csv","a",newline="", encoding='utf-8') as csvfile : # j'ouvre le fichier recherche et je l'appelle csvfile et je met a pour rajouter a la fi du texte les nouveau nom si il y en a
                csvfile.write(nom_utilisateur+","+str(ancien_score)) # j'ajoute le nom au fichier a la fin
    else: # ou alors :
        if int(ancien_score)<int(score): # si l'ancien score est inferieur au nouveau
            ancien_score=score # alors l'ancien score devient le nouveau
            toile.itemconfig(affichage_ancien_score, text='Best score = '+str(ancien_score)) # je modifie le meuilleur score
            with open("recherche.csv","r") as f: # j'ouvre le fichier avec tout les noms et score
                lines = f.readlines() # je regarde chaque ligne
                ptr=1 # j'augmente de 1 a ptr
                with open("recherche.csv","w") as outpute: #j'ouvre le fichier et je vais le modifier
                    for line in lines : # pour chaque ligne dans le fichier lines
                        if ptr != (len(tableau)): # si ptr est diferent du numero de joueur alors :
                            outpute.write(line) # j'ecrit la ligne dans le nouveau fichier
                        ptr+=1 # j'augmente de 1 a ptr
            with open ("recherche.csv","a",newline="", encoding='utf-8') as csvfile : # j'ouvre le fichier recherche et je l'appelle csvfile et je met a pour rajouter a la fi du texte les nouveau nom si il y en a
                csvfile.write(nom_utilisateur+","+str(ancien_score)) # j'ajoute le nom au fichier a la fin
    for elmt in l_mechant: # pour chaque element dans la liste l_mechant :
        toile.delete(elmt[0]) # je supprime tout les monstres de la toile
    for elt in l_fleche: # pour chaque element dans la liste l_fleche :
        toile.delete(elt[0]) # je supprime toute les fleches dans la toile
    mort=True # on commence par mettre la mort de cupidon en vrai
    horaire=0 # on definit le temps de jeu a 0
    n=1 # le nombre de monstre qui sponne est initialiser a 1
    double_fleche=False # on commenece par mettre le bonnus double-fleche en faux
    fusee_rouge=False # on commenece par mettre le bonnus fusee_explosive en faux
    temps_de_jeu=10  # on met le temps du bonus double fleche a 10s avant de l'obtenir
    score=0  # le score vaut 0 en debut de parti
    fleche_destructive=False # on commence par mettre le bonnus fleche_destructive en false
    temps_fleche_indestructible=20  # on met le temps du bonus fleche_destructive a 20s avant de l'obtenir
    action='passif'   #on initialise l'action de cupidon en passif
    sens='gauche' # on met le sens des mechants a gauche
    temps_fusee=30 # on met le temps du bonus fusee explosive a 30s avant de l'obtenir
    l_mechant=[] # on créer une liste pour mettre touts les mechants dedans
    l_fleche=[]   # on créer une liste pour mettre toutes les fleches dedans
    l_explosion=[] # on créer une liste pour mettre toutes les explosions dedans
    l_mine=[] # on créer une liste pour mettre toutes les clotures dedans
    t=0   # t représente un compteur de "temps" qu'on met a 0
    time_shield=-1 # on met le temps du bouclier a -1
    temps_bouclier=25 # on initialise le temps avant d'obtenir le bouclier comme bonus
    bouclier_action=False #on initialise bouclier_action en false
    temps=7000 #on definti le temps de pop des monstres
    temps_afficher_mine=13 # je definit quand cupidon va pouvoir poser une mine
    health=5 # on definit le nombre de vie que cupidon aura
    hit=False # on definit que cupidon n'est pas toucher
    temps_carapce=32 # on definit le temps du bonus carapace_rouge a 32s avant de l'obtenir
    carapace_rouge=False # on commence par mettre le bonnus carapace_rouge en false
    nombre_de_mechants_toucher_carapace=0 # je definit le nombre de mechants toucher a 0
    nombre_max_carapace=0 # et le nombre de mechants toucher quelle pourra toucher a 0
    v=0 # on initialise le nombre de mort des monstres a 0 pour permettre a la carapace de prendre 1 monstre a la fois
    x_cupidon=500    # on initialise les coordonnées de cupidon (au centre de l'image)
    y_cupidon=300
    mine_vf=False # je definit le terme mine pas disponible donc en false






def jeu_en_pause():
    '''fonction qui met le jeu en pause'''
    global image_fond,bouton_aide,mort,in_game,bouton2,bouton3,affichage_de_pause # on prend les valeurs en global qui nous interresse
    bouton2.destroy() # je detruit le bouton numero2
    in_game=True # je dit que nous sommes en game
    affichage_de_pause=toile.create_image(500,300,image=image_fond[1]) # j'affiche une image du jeux en pause
    mort=True # je dit que la mort est vrai pour que le jeu se mette sur pause
    bouton_aide.destroy() #je detruit le bouton aide
    bouton_aide = tk.Button(fenetre, text='AIDE', command =lambda: ( aide_des_bonus())) # on crée un bouton pour aider le joueur avec les bonus
    bouton_aide.pack() # on ajoute le bouton a la toile
    bouton3 =tk.Button(fenetre, text='!>',command=lambda:(jeu_reprend())) # je créer le bouton 3 pour pouvoir reprendre le jeux
    bouton3.pack() # on ajoute le bouton a la toile


def jeu_reprend():
    '''fonction qui va faire repartir le jeu '''
    global bouton3,bouton_aide,affichage_de_pause,ancien_score,affichage_ancien_score,afficher_nom_utilisateur,nom_utilisateur # on prend les valeurs en global qui nous interresse
    toile.delete(affichage_de_pause) # je suprime l'image du jeux en pause
    bouton3.destroy() # je detruis le bouton numero 3
    affichage_ancien_score=toile.create_text(905,35,text='Best score = '+str(ancien_score),font=('Roman',12),fill="black") #et on affiche le score
    afficher_nom_utilisateur=toile.create_text(500,590,text= nom_utilisateur,font=('Castellar',17),fill="black") # je créer ce texte pour afficher le nom de l'utilisateur en bas de la toile
    comptareboure(0) # j'appelle la fonction comptareboure

def jeu_reprend2():
    '''fonction qui va etre appeller par l'aide des bonus et qui va tout supprimer et créer un bouton pour relancer la partie'''
    global bouton_aide,bouton3,affichage_de_pause,bouton_quitter_aide,image_bonus0,image_bonus1,image_bonus2,image_bonus3,image_bonus4,image_bonus5,image_bonus6,texte_bonus1,texte_bonus2,texte_bonus3,texte_bonus4,texte_bonus5,texte_bonus6,texte_bonus_1,texte_bonus_2,texte_bonus_3,texte_bonus_4,texte_bonus_5,texte_bonus_6 # on prend les valeurs en global qui nous interresse
    toile.delete(image_bonus0,image_bonus1,image_bonus2,image_bonus3,image_bonus4,image_bonus5,image_bonus6,texte_bonus1,texte_bonus2,texte_bonus3,texte_bonus4,texte_bonus5,texte_bonus6,texte_bonus_1,texte_bonus_2,texte_bonus_3,texte_bonus_4,texte_bonus_5,texte_bonus_6) # je supprime toute les images et tout les textes
    toile.itemconfigure(affichage_de_pause, image=image_fond[1]) # je change le fond
    bouton_aide.destroy() # je détruit le bouton aide
    bouton_aide = tk.Button(fenetre, text='AIDE', command =lambda: ( aide_des_bonus())) # on crée un bouton pour aider le joueur avec les bonus
    bouton_aide.pack() # on ajoute le bouton a la toile
    bouton_quitter_aide.destroy() # je detruit le bouton qui sert a quitter la page d'aide
    bouton3 = tk.Button(fenetre, text='!>', command =lambda: ( jeu_reprend())) # on crée un bouton pour aider le joueur avec les bonus
    bouton3.pack() # on ajoute le bouton a la toile





def comptareboure(t):
    '''fonction qui fera un  comptarebour avant de commencer a jouer'''
    global temps_reprendre_jeu,mort,bouton2,image_fond,bouton3,bouton_aide # on prend les valeurs en global qui nous interresse
    if t==0: # si t vaut 0
        bouton_aide.destroy() #je detruit le bouton aide
        toile.itemconfigure(fond_de_jeu,image=image_fond[0]) # je change le fond
        toile.itemconfig(temps_reprendre_jeu,text='3')  # on modifie le temps sur la toile
    if t==1: # si t vaut 1
        toile.itemconfig(temps_reprendre_jeu,text='2')  # on modifie le temps sur la toile
    if t==2: # si t vaut 2
        toile.itemconfig(temps_reprendre_jeu,text='1')  # on modifie le temps sur la toile
    if t==3: # si t vaut 3
        toile.itemconfig(temps_reprendre_jeu,text='GO')  # on modifie l'affichage sur la toile
    if t ==4 : # si t vaut 4
        toile.itemconfig(temps_reprendre_jeu,text=' ')  # on modifie l'affichage sur la toile
        mort=False # je met cupidon en vie pour que le jeux reprenne
        battement_aille() # j'appelle la fonction battement aille
        bouton2 =tk.Button(fenetre, text='//',command=lambda:(jeu_en_pause())) # je créer le bouton 2 pour pouvoir remettre le jeux en pause
        bouton2.pack() # on ajoute le bouton a la toile
    if t <5: # si t est inferieur a 5
        toile.after(1000,comptareboure,t+1)  # on rapelle en boucle la fonction (récursivité) toute les secondes

def debut_s_restard():
    '''fonction qui fait toute les modifications nécessaires pour permettre de recommencer la partie sans difficulter'''
    global mot_de_depart2,cuddi,music_chargement,vague_de_monstre_temps,afficher_nom_utilisateur,nom_utilisateurx_cupidon,y_cupidon,parametre,photo_profile,mot_de_depart,temps_reprendre_jeu,affiche_temps_mine,mine_sur_toile,carapace_rouge_sur_toile,bouclier_sur_toile,fleche_indestructible_toile,double_fleche_sur_toile_1,double_fleche_sur_toile,fusee_sur_toile,health_bar,affiche_temps_bouclier,affiche_temps_carapace,temps_en_haut,affiche_temps_fusee,mot_de_depart3,cupidon,texte,affiche_score,affiche_temps_de_jeu,affiche_temps_de_fleche_indestructible # on prend les valeurs en global qui nous interresse
    toile.delete(mot_de_depart2) # je supprime toute les images et les textes de l'acceuil qui nous seront plus utiles
    toile.delete(mot_de_depart)
    toile.delete(mot_de_depart3)
    toile.delete(mot_de_depart4)
    toile.delete(cuddi)
    toile.delete(photo_profile)
    toile.delete(parametre)
    music_chargement.stop() # je stop la music
    bouton4.destroy() #je détruit le bouton numero4
    vague_de_monstre_temps=16 #je definit le temps pour lequel on changera de vague 16
    cupidon=toile.create_image(x_cupidon, y_cupidon, image =images_cupidon[0]) # on ajoute cupidon à la fenêtre
    fleche_toucher_mechant() # on appel la fonction fleche_toucher_mechant
    texte=toile.create_text(500,40,text="Vague numéro "+str(n)+" !",font=('Impact',30),fill="blue") # on créer le texte sur la toile pour dire a qu'elle vague on en est
    affiche_score=toile.create_text(914,17,text="score : "+str(score),font=('Arial',15),fill="black") # on créer sur la toile le score qui est initialement a 0
    affiche_temps_de_jeu=toile.create_text(75,8,text=" : "+str(temps_de_jeu)+" x",font=('Candara',10),fill="black") # on affiche sur la toile dans combien de temps est disponible le bonus double-fleche
    affiche_temps_de_fleche_indestructible=toile.create_text(67,22,text=" : "+str(temps_fleche_indestructible)+' c',font=('Candara',10),fill="black")  # on affiche sur la toile dans combien de temps est disponible le bonus fleche indestructible
    affiche_temps_fusee=toile.create_text(55,38,text=" : "+str(temps_fusee)+' v',font=('Candara',10),fill="black") # on affiche sur la toile dans combien de temps est disponible le bonus carapace explosive
    affiche_temps_carapace=toile.create_text(55,58,text=" : "+str(temps_carapce)+' n',font=('Candara',10),fill="black") # on affiche sur la toile dans combien de temps est disponible le bonus carapace explosive
    temps_en_haut=toile.create_text(500,15,text=" Temps de jeu : "+str(horaire),font=('Arial',11),fill="black") #on créer un texte qui met le temps de jeu sur la toile
    affiche_temps_bouclier=toile.create_text(155,22,text=" : "+str(temps_bouclier)+ ' b',font=('Candara',10),fill="black") # on créer sur la toile un texte qui affichera le temps d'attente avant d'obtenir le bonus bouclier
    health_bar=toile.create_image(750, 25, image =images_health[5]) # on ajoute la barre de vie à la fenêtre
    fusee_sur_toile=toile.create_image(25, 40, image =image_fusée1[0]) # je créer l'image sur la toile de la fusée bonus
    double_fleche_sur_toile=toile.create_image(15, 10, image =images_fleches_toile[0]) # je créer l'image de la premier fleche pour la double fleche sur la toile comme bonus
    double_fleche_sur_toile_1=toile.create_image(45, 10, image =images_fleches_toile[1]) # je créer l'image de la deuxieme fleche pour la double fleche sur la toile comme bonus
    fleche_indestructible_toile=toile.create_image(25, 22, image =images_fleches_indestructible_1[0])  # je créer l'image sur la toile de la fleche indestructible bonus
    bouclier_sur_toile=toile.create_image(120, 22, image =image_bouclier_1[0])  # je créer l'image sur la toile du bouclier comme bonus
    carapace_rouge_sur_toile=toile.create_image(20,60, image =image_carapace_rouge1[0])  # je créer l'image sur la toile de la carapace rouge comme bonus
    mine_sur_toile=toile.create_image(105,55, image =image_mine1[0])  # je créer l'image sur la toile de la mine comme bonus
    affiche_temps_mine=toile.create_text(136,55,text=' : '+str(temps_afficher_mine)+ ' w',font=('Candara',10),fill="black") # on créer sur la toile un texte qui affichera le temps d'attente avant d'obtenir le bonus mine
    temps_reprendre_jeu=toile.create_text(500,300,text=' ',font=('Bell MT',100),fill="black") # je créer un texte vide qui fera un top depart
    music_en_fond() # j'appelle toute les fonction dont on aura besoin au depart pour jouer
    afficher_nom_utilisateur=toile.create_text(500,590,text= nom_utilisateur,font=('Castellar',17),fill="black") # je créer ce texte pour afficher le nom de l'utilisateur en bas de la toile
    comptareboure(0) # on appelle la fonction comptaboure


def tout_debut():
    '''fonction qui est appeler au debut du jeu pour supprimer la page d'acceuil et aussi de lacer toute les fonctions dont on aura besoin'''
    global mot_de_depart2,cuddi,music_chargement,deja_jouer,afficher_nom_utilisateur,nom_utilisateur,x_cupidon,y_cupidon,parametre,photo_profile,mot_de_depart,temps_reprendre_jeu,affiche_temps_mine,mine_sur_toile,carapace_rouge_sur_toile,bouclier_sur_toile,fleche_indestructible_toile,double_fleche_sur_toile_1,double_fleche_sur_toile,fusee_sur_toile,health_bar,affiche_temps_bouclier,affiche_temps_carapace,temps_en_haut,affiche_temps_fusee,mot_de_depart3,cupidon,texte,affiche_score,affiche_temps_de_jeu,affiche_temps_de_fleche_indestructible # on prend les valeurs en global qui nous interresse
    toile.delete(mot_de_depart2) # je supprime toute les images et les textes de l'acceuil qui nous seront plus utiles
    toile.delete(mot_de_depart)
    toile.itemconfig(mot_de_depart3,text='')
    toile.delete(mot_de_depart4)
    toile.delete(cuddi)
    toile.delete(photo_profile)
    toile.delete(parametre)
    music_chargement.stop() # je stop la music chargement

    cupidon=toile.create_image(x_cupidon, y_cupidon, image =images_cupidon[0]) # on ajoute cupidon à la fenêtre
    fleche_toucher_mechant() # on appel la fonction fleche_toucher_mechant
    texte=toile.create_text(500,40,text="Vague numéro "+str(n)+" !",font=('Impact',30),fill="blue") # on créer le texte sur la toile pour dire a qu'elle vague on en est
    affiche_score=toile.create_text(914,17,text="score : "+str(score),font=('Arial',15),fill="black") # on créer sur la toile le score qui est initialement a 0
    affiche_temps_de_jeu=toile.create_text(75,8,text=" : "+str(temps_de_jeu)+" x",font=('Candara',10),fill="black") # on affiche sur la toile dans combien de temps est disponible le bonus double-fleche
    affiche_temps_de_fleche_indestructible=toile.create_text(67,22,text=" : "+str(temps_fleche_indestructible)+' c',font=('Candara',10),fill="black")  # on affiche sur la toile dans combien de temps est disponible le bonus fleche indestructible
    affiche_temps_fusee=toile.create_text(55,38,text=" : "+str(temps_fusee)+' v',font=('Candara',10),fill="black") # on affiche sur la toile dans combien de temps est disponible le bonus carapace explosive
    affiche_temps_carapace=toile.create_text(55,58,text=" : "+str(temps_carapce)+' n',font=('Candara',10),fill="black") # on affiche sur la toile dans combien de temps est disponible le bonus carapace explosive
    temps_en_haut=toile.create_text(500,15,text=" Temps de jeu : "+str(horaire),font=('Arial',11),fill="black") #on créer un texte qui met le temps de jeu sur la toile
    affiche_temps_bouclier=toile.create_text(155,22,text=" : "+str(temps_bouclier)+ ' b',font=('Candara',10),fill="black") # on créer sur la toile un texte qui affichera le temps d'attente avant d'obtenir le bonus bouclier
    health_bar=toile.create_image(750, 25, image =images_health[5]) # on ajoute la barre de vie à la fenêtre
    fusee_sur_toile=toile.create_image(25, 40, image =image_fusée1[0]) # je créer l'image sur la toile de la fusée bonus
    double_fleche_sur_toile=toile.create_image(15, 10, image =images_fleches_toile[0]) # je créer l'image de la premier fleche pour la double fleche sur la toile comme bonus
    double_fleche_sur_toile_1=toile.create_image(45, 10, image =images_fleches_toile[1]) # je créer l'image de la deuxieme fleche pour la double fleche sur la toile comme bonus
    fleche_indestructible_toile=toile.create_image(25, 22, image =images_fleches_indestructible_1[0])  # je créer l'image sur la toile de la fleche indestructible bonus
    bouclier_sur_toile=toile.create_image(120, 22, image =image_bouclier_1[0])  # je créer l'image sur la toile du bouclier comme bonus
    carapace_rouge_sur_toile=toile.create_image(20,60, image =image_carapace_rouge1[0])  # je créer l'image sur la toile de la carapace rouge comme bonus
    mine_sur_toile=toile.create_image(105,55, image =image_mine1[0])  # je créer l'image sur la toile de la mine comme bonus
    affiche_temps_mine=toile.create_text(136,55,text=' : '+str(temps_afficher_mine)+ ' w',font=('Candara',10),fill="black") # on créer sur la toile un texte qui affichera le temps d'attente avant d'obtenir le bonus mine
    temps_reprendre_jeu=toile.create_text(500,300,text=' ',font=('Bell MT',100),fill="black") # je créer un texte vide qui fera un top depart
    afficher_nom_utilisateur=toile.create_text(500,590,text= nom_utilisateur,font=('Castellar',17),fill="black") # je créer ce texte pour afficher le nom de l'utilisateur en bas de la toile
    music_en_fond() # j'appelle toute les fonctions dont on aura besoin au depart pour jouer
    temps_pour_la_mine()
    carapace_rouge_avancer()
    pop_mechant()
    deplacement_mechant()
    avancer_fleche()
    mechant_touche_cupidon()
    tirer_2_sens_disponible()
    fleche_destructive_disponible()
    temps_()
    fusee_explosive()
    skill_shield()
    carapace_rouge_temps()
    temps_vague_de_monstre()
    battement_aille_mechant(0)  #on appelle la fonction battement_aille_mechant

def page_d_acceuil():
    '''fonction qui créer une page d'accbouton_aideeuil'''
    global fond_de_jeu,in_game,deja_jouer,bouton4,bouton_aide,bouton1,bouton_quitter_aide,aide,image_bonus0,image_bonus1,image_bonus2,image_bonus3,image_bonus4,image_bonus5,image_bonus6,texte_bonus1,texte_bonus2,texte_bonus3,texte_bonus4,texte_bonus5,texte_bonus6,texte_bonus_1,texte_bonus_2,texte_bonus_3,texte_bonus_4,texte_bonus_5,texte_bonus_6,nom_utilisateur_rentre,lettre,ancien_score,drapeau,parametre,cuddi,photo_profile,mot_de_depart,mot_de_depart2,mot_de_depart3,mot_de_depart4,affichage_ancien_score,zone_entree # on prend les valeurs en global qui nous interresse
    if aide==True: # si j'ai été dans le menu d'aide :
        in_game=False # je dit que in_game est faux car je suis sur la page d'acceuil
        bouton_quitter_aide.destroy() # je detruit le bouton qui permet de quitter la fenetre aide
        bouton_aide.destroy()# je detruit le bouton aide
        bouton_aide = tk.Button(fenetre, text='AIDE', command =lambda: ( aide_des_bonus())) # on crée un bouton pour aider le joueur avec les bonus
        bouton_aide.pack() # on ajoute le bouton a la toile
        toile.delete(image_bonus0,image_bonus1,image_bonus2,image_bonus3,image_bonus4,image_bonus5,image_bonus6,texte_bonus1,texte_bonus2,texte_bonus3,texte_bonus4,texte_bonus5,texte_bonus6,texte_bonus_1,texte_bonus_2,texte_bonus_3,texte_bonus_4,texte_bonus_5,texte_bonus_6) # je supprime toute les images et tout les textes
        if deja_jouer==False: # si deja_jouer est faux alors :
            bouton1 = tk.Button(fenetre, text='START', command =lambda: ( tout_debut(),comptareboure(0) )) # on crée un bouton pour "commencer" et pour lancer le jeu
            bouton1.pack() # on ajoute le bouton a la toile
            toile.itemconfig(affichage_ancien_score, text='Best score = '+str(ancien_score)) # je modifie le meuilleur score
        elif deja_jouer==True : # si deja_jouer est vrai alors :
            bouton4.destroy() #je detruit le bouton numero 4
            bouton4 = tk.Button(fenetre, text='RESTART', command =lambda: ( debut_s_restard() )) # on crée un bouton pour "commencer" et pour lancer le jeu
            bouton4.pack() # on ajoute le bouton a la toile
    fond_de_jeu=toile.create_image(500, 300, image =image_fond[2]) # on ajoute un nouveau fond à la fenêtre
    drapeau=toile.create_image(980, 578, image =image_drapeau[0]) # on ajoute un drapeau à la fenêtre
    parametre=toile.create_image(980, 22, image =image_parametre[0]) # on ajoute l'image du logo parametre à la fenêtre
    cuddi=toile.create_image(500, 150, image =image_cuddi[0]) # on ajoute une cupidon à la fenêtre
    photo_profile=toile.create_image(60,60,image=image_photo_profile[0]) # j'ajoute l'image de la photo de profile
    mot_de_depart=toile.create_text(500,250,text='Bienvenue dans le jeu ',font=('Roman',60),fill="black") # je créer un texte permettant de dire bonjour au joueur
    mot_de_depart2=toile.create_text(500,350,text='CUPIDON',font=('Roman',60),fill="black") # je créer un texte disant le nom du jeu
    if nom_utilisateur_rentre==1: # si le nom_d'utilisateur a deja ete rentrer :
        mot_de_depart4=toile.create_text(60,132,text= nom_utilisateur,font=('Castellar',17),fill="black") # je créer ce texte pour mettre le nom d'utilisateur
        toile.delete(affichage_ancien_score)# je supprime l'affichage_ancien_score car il se trouve derrieur l'ancien fond et on ne le voit plus
        affichage_ancien_score=toile.create_text(905,35,text='Best score = '+str(ancien_score),font=('Roman',12),fill="black") #je créer un text avec le score max que le joueur a deja eu
        mot_de_depart3=toile.create_text(500,591,text='Appuyer pour commencer',font=('Arial',10),fill="black") # j'explique au joueur ou appuyer pour commencer en créant ce texte
    if nom_utilisateur_rentre==0: # si le nom_d'utilisateur n'a jamais ete rentrer : soit le jeu vient d'etre lancer
        mot_de_depart3=toile.create_text(500,591,text='Entrez votre nom',font=('Arial',10),fill="black") # j'explique au joueur qu'il faut rentrer son nom
        lettre=tk.StringVar(fenetre) #je definit le terme lettre
        zone_entree=tk.Entry(fenetre, font=('Arial',15), textvariable=lettre) # zone de saisie pour que le joueur puisse proposer son nom
        zone_entree.pack() # j'ajoute la zone de saisit a la fentre
        zone_entree.bind("<Return>", traiter_lettre)# si le touche Entrée est enfoncée, on fait appel à la fonction traiter_lettre
        nom_utilisateur_rentre+=1 # j'augmente de 1 pour qu'on ne puisse pas redemander le nom

def traiter_lettre(event):
    '''fonction qui permet d'afficher son nom dans le jeu grace a une zone de saisit'''
    global nom_utilisateur,ancien_score,bouton_aide,new_player,restard,numero_joueur,nom,mot_de_depart4,zone_entree,bouton1,mot_de_depart3,affichage_ancien_score,score,table,tableau # on prend les valeurs en global qui nous interresse
    nom_utilisateur=lettre.get() #récupère le mot taper au clavier dans la zone de saisie sur tkinter
    tableau=list(table) #je met table sous forme de liste
    for elmt in range(len(tableau)) : # pour la longueur de la liste
        if nom_utilisateur == tableau[elmt][0]: # si le nom_utilisateur est dans table alors:
            ancien_score = tableau[elmt][1] # on recupere son ancien score
            affichage_ancien_score=toile.create_text(905,35,text='Best score = '+str(ancien_score),font=('Roman',12),fill="black") #et on affiche le score
            nom=True # je dit que il y a deja un nom
            numero_joueur=elmt # je definit le numero de joueur
    if nom == False : #si le nom n'est pas dans la table
        restard=True # je dit que le restard devient vrai
        new_player=True # je dit que le new_player devient vrai
        affichage_ancien_score=toile.create_text(905,35,text='',font=('Roman',12),fill="black") # je créer un texte vide
        numero_joueur=len(tableau) # je d'éfnit le termes numero_joueur avec la longueur du tableau
        with open ("recherche.csv",'a',newline="" , encoding='utf-8') as csvfile : # j'ouvre le fichier recherche et je l'appelle csvfile et je met a pour rajouter a la fi du texte les nouveau nom si il y en a
            csvfile.write("\n"+nom_utilisateur+",0") # j'ajoute le nom au fichier et je lui met un score de 0
    mot_de_depart4=toile.create_text(60,132,text= nom_utilisateur,font=('Castellar',17),fill="black") # je créer ce texte pour mettre le nom d'utilisateur
    zone_entree.destroy() #supprime la zone de saisie
    bouton_aide = tk.Button(fenetre, text='AIDE', command =lambda: ( aide_des_bonus())) # on crée un bouton pour aider le joueur avec les bonus
    bouton_aide.pack() # on ajoute le bouton a la toile
    bouton1 = tk.Button(fenetre, text='START', command =lambda: ( tout_debut(),comptareboure(0) )) # on crée un bouton pour "commencer" et pour lancer le jeu
    bouton1.pack() # on ajoute le bouton a la toile
    toile.itemconfig(mot_de_depart3,text='Appuyer pour commencer') # je change le texte pour qu'il appuye sur start pour commencer

def musique_pour_chargement():
    '''fonction qui relancera la musique si on est encore dans le chargement'''
    global in_game,music_chargement # on prend les valeurs en global qui nous interresse
    if in_game==False: # si in_game est en false alors
        music_chargement.stop() # on joue la music
        music_chargement.play(0) # on joue la music
        toile.after(144000,musique_pour_chargement) # on rapelle en boucle la fonction (récursivité)



# on définit les variables globales
horaire=0 # on definit le temps de jeu a 0
largeur=1000        # on définit les dimensions de la fenêtre
hauteur=600
direction='gauche'  # variable globale qui donne la direction de cupidon : 'gauche' ou 'droite'
x_cupidon=largeur//2    # on initialise les coordonnées de cupidon (au centre de l'image)
y_cupidon=hauteur//2
mort=True # on commence par mettre la mort de cupidon en vrai
n=1 # le nombre de mob qui sponne est initialiser a 1
double_fleche=False # on commenece par mettre le bonnus double-fleche en faux
fusee_rouge=False # on commenece par mettre le bonnus fusee_explosive en faux
temps_de_jeu=10  # on met le temps du bonus double fleche a 10s avant de l'obtenir
score=0  # le score vaut 0 en debut de parti
fleche_destructive=False # on commenece par mettre le bonnus fleche_destructive en false
temps_fleche_indestructible=20  # on met le temps du bonus fleche_destructive a 20s avant de l'obtenir
action='passif'   #on initialise l'action de cupidon en passif
sens='gauche' # on met le sens des mechants a gauche
temps_fusee=30 # on met le temps du bonus fusee explosive a 30s avant de l'obtenir

l_mechant=[] # on créer une liste pour mettre touts les mechants dedans
l_fleche=[]   # on créer une liste pour mettre toutes les fleches dedans
l_explosion=[] # on créer une liste pour mettre toutes les explosions dedans
l_mine=[] # on créer une liste pour mettre toutes les mines dedans

t=0   # t représente un compteur de "temps" qu'on met a 0
time_shield=-1 # on met le temps du bouclier a -1
temps_bouclier=25 # on initialise le temps avant d'obtenir le bouclier comme bonus
bouclier_action=False #on initialise bouclier_action en false
temps=7000 #on definti le temps de pop des monstres
temps_afficher_mine=13 # je definit quand cupidon va pouvoir poser une mine
health=5 # on definit le nombre de vie que cupidon aura
restard=False #je definit restard en false
hit=False # on definit que cupidon n'est pas toucher
temps_carapce=32 # on definit le temps du bonus carapace_rouge a 32s avant de l'obtenir
carapace_rouge=False # on commenece par mettre le bonnus carapace_rouge en false
nombre_de_mechants_toucher_carapace=0 # je definit le nombre de mechants toucher par la carapace a 0
nombre_max_carapace=0 # et le nombre de mechants toucher max par la carapace quelle pourra toucher je l'initialise a 0
v=0 # on initialise le nombre de mort des monstres a 0 pour permettre a la carapace de prendre 1 monstre a la fois
mine_vf=False # je definit le terme mine qui n'est pas disponible pour l'instant
ancien_score=0 #je definit le score ancien a 0
nom_utilisateur_rentre=0 #je defnit le nombre de fois qu'on puisse rentrer son nom
nom=False # je definit le terme nom en false
new_player=False # je definit le terme new_player en false
aide=False # je definit aide en false
in_game=False # je définis le faite que nous sommes pas en game
deja_jouer=False # je défiinit le faite qu'on n'est toujours pas fait de partie
vague_de_monstre_temps=16 # je définit le temps de la vague a 16
coordonnee1=0 # je defini la taille de l'image d'acceuil a 0
coordonnee2=0
# on définit les éléments de la fenêtre
fenetre=tk.Tk()     # on créé la fenêtre
toile = tk.Canvas(fenetre, width=largeur, height=hauteur)   # on crée une "toile" dans la fen^tre dans laquelle on pourra dessiner
toile.pack()        # on place la toile dans la fenêtre

with open ("recherche.csv","r",newline="" , encoding='utf-8') as csvfile : # j'ouvre le fichier recherche et je l'appelle csvfile
    table=list(csv.reader(csvfile)) # je definit le terme table





# on s'occupe des différentes images

images_cupidon=[]      # liste qui va contenir toutes les images de cupidon
images_fleche=[]      # liste qui va contenir toutes les images des fleches
images_mechant=[]    # liste qui va contenir toutes les images des mechants
images_fleches_indestructible=[] # liste qui va contenir toutes les images des fleches indestructibles
images_explosion=[] # liste qui va contenir toutes les images des explosions
image_carapace_rouge=[]# liste qui va contenir toutes les images des carapaces rouges
image_bouclier=[] # liste qui va contenir toutes le image du bouclier
image_fusée=[] # liste qui va contenir toutes les images des  fusées
images_health=[] # liste qui va contenir toutes les images de la barre de vie
image_toucher=[] # liste qui va contenir toutes les images de cupidon en rouge
image_fusée1=[] # je créer une liste qui va contenir la petite image du bonus fusée
images_fleches_toile=[] # je créer une liste qui va contenir les petites image du bonus double-fleche
images_fleches_indestructible_1=[] # je créer une liste qui va contenir la petite image du bonus fleche indestructible
image_bouclier_1=[] # je créer une liste qui va contenir la petite image du bonus boucier
image_carapace_rouge1=[] # je créer une liste qui va contenir la petite image du bonus carapace rouge
image_mine=[] # je créer une liste qui va contenir les images de la mine
image_mine1=[] # je créer une liste qui va contenir la petite image du bonus mine
image_fond=[] # je créer une list qui va contenir les images des differents fonds
image_drapeau=[] # je créer une liste qui va contenir l'images du drapeau francais
image_parametre=[] #je créer une liste qui va contenir l'image du logo parametre
image_cuddi=[] #je créer une liste qui va contenir l'image de cupidon au debut sur la page d'acceuil
image_photo_profile=[] #je créer une liste qui va contenir l'image de la photo de profile

img_drapeau=Image.open('drapeau'+'.png')    # on ouvre l'image qui servira de drapeau
img_drapeau=img_drapeau.resize((35, 50))    # on redimensionne l'image par rapport à la taille de la fenêtre
image_drapeau.append(ImageTk.PhotoImage(img_drapeau, master=fenetre))     # on ajoute l'image à la liste

img_parametre=Image.open('parametre'+'.png')    # on ouvre l'image qui servira de parametre
img_parametre=img_parametre.resize((35, 30))    # on redimensionne l'image par rapport à la taille de la fenêtre
image_parametre.append(ImageTk.PhotoImage(img_parametre, master=fenetre))     # on ajoute l'image à la liste

img_cuddi=Image.open('cuddi'+'.png')    # on ouvre l'image qui servira de cupidon a la page d'acceuil
img_cuddi=img_cuddi.resize((140, 140))    # on redimensionne l'image par rapport à la taille de la fenêtre
image_cuddi.append(ImageTk.PhotoImage(img_cuddi, master=fenetre))     # on ajoute l'image à la liste

img_photo=Image.open('photo_profile'+'.png')    # on ouvre l'image qui servira de photo de profile
img_photo=img_photo.resize((100, 100))    # on redimensionne l'image par rapport à la taille de la fenêtre
image_photo_profile.append(ImageTk.PhotoImage(img_photo, master=fenetre))     # on ajoute l'image à la liste


for i in range (1):
    img_fond=Image.open('fond'+str(i)+'.jpg')     # on ouvre l'image qui servira de fond d'écran
    img_fond=img_fond.resize((largeur, hauteur))    # on redimensionne l'image par rapport à la taille de la fenêtre
    image_fond.append(ImageTk.PhotoImage(img_fond, master=fenetre))     # on ajoute l'image à la liste


img_fond=Image.open('fond1.jpg')     # on ouvre l'image qui servira de fond d'écran
img_fond=img_fond.resize((largeur, hauteur))    # on redimensionne l'image par rapport à la taille de la fenêtre
image_fond.append(ImageTk.PhotoImage(img_fond, master=fenetre))     # on ajoute l'image à la liste


img_start=Image.open('acceuil'+'.png')    # on ouvre l'image qui servira de fond d'accueil
img_start=img_start.resize((largeur, hauteur))    # on redimensionne l'image par rapport à la taille de la fenêtre
image_fond.append(ImageTk.PhotoImage(img_start, master=fenetre))     # on ajoute l'image à la liste

supercell=Image.open('affichage_debut'+'.jpg')    # on ouvre l'image qui servira de premiere image

for i in range(26):
    img=Image.open('perso_'+str(i)+'.png')     # on ouvre l'image numéro "i" de cupidon
    images_cupidon.append(ImageTk.PhotoImage(img, master=fenetre))     # on ajoute l'image à la liste
for i in range(1,3):
    img1=Image.open('fleche'+str(i)+'.png')     # on ouvre l'image numéro "i" de fleche
    images_fleche.append(ImageTk.PhotoImage(img1, master=fenetre))     # on ajoute l'image à la liste
for i in range(19):
    img=Image.open('mechant_'+str(i)+'.png')     # on ouvre l'image numéro "i" du mechant
    images_mechant.append(ImageTk.PhotoImage(img, master=fenetre))     # on ajoute l'image à la liste
for i in range(1,3):
    img_fleche_dure=Image.open('fleche'+str(i)+'.png')     # on ouvre l'image numéro "i" de fleche
    img_fleche_dure=img_fleche_dure.resize((72,13))   # je modifie l'image pour qu'elle soit plus grosse
    images_fleches_indestructible.append(ImageTk.PhotoImage(img_fleche_dure, master=fenetre))     # on ajoute l'image à la liste
for i in range (6):
    img_explosion=Image.open('img_explosion'+str(i)+'.png')     # on ouvre l'image numéro "i" de l'explosion
    img_explosion=img_explosion.resize((300,300))   # je modifie l'image pour qu'elle soit plus petite
    images_explosion.append(ImageTk.PhotoImage(img_explosion, master=fenetre))     # on ajoute l'image à la liste
for i in range (2):
    img_carapace_rouge=Image.open('carapace_rouge'+str(i)+'.png')     # on ouvre l'image numéro "i" des carapaces rouges
    img_carapace_rouge=img_carapace_rouge.resize((40,40))   # je modifie l'image pour qu'elle soit plus petite
    image_carapace_rouge.append(ImageTk.PhotoImage(img_carapace_rouge, master=fenetre))     # on ajoute l'image à la liste
for i in range(1):
    img_bouclier=Image.open('bouclier2.png')     # on ouvre l'image qui servira de bouclier
    img_bouclier=img_bouclier.resize((100, 100))    # on redimensionne l'image par rapport à la taille du cupidon
    image_bouclier.append( ImageTk.PhotoImage(img_bouclier, master=fenetre))  # permet de pouvoir ajouter l'image à la toile
for i in range (1,3):
    img_fusée=Image.open('fusee_'+str(i)+'.png')    # on ouvre l'image numéro "i" des fusées
    img_fusée=img_fusée.resize((50, 50))    # on redimensionne l'image de la fusée
    image_fusée.append(ImageTk.PhotoImage(img_fusée, master=fenetre))     # on ajoute l'image à la liste
for i in range(6):
    img_healt=Image.open('health'+str(i)+'.png') # on ouvre l'image numéro "i" des barres de vies
    img_healt=img_healt.resize((155, 25))    # on redimensionne l'image sur la toile
    images_health.append(ImageTk.PhotoImage(img_healt, master=fenetre))     # on ajoute l'image à la liste

for i in range(1,5):
    img_toucher=Image.open('perso_26 ('+str(i)+').png') # on ouvre l'image qui servira a montrer que cupidon est touchée
    img_toucher=img_toucher.resize((800, 800))    # on redimensionne l'image
    image_toucher.append(ImageTk.PhotoImage(img_toucher, master=fenetre))    # on ajoute l'image à la liste

img_fusée1=Image.open('fusee_2'+'.png')    # on ouvre l'image qui servira de fusée
img_fusée1=img_fusée1.resize((30, 30))    # on redimensionne l'image de la fusée
image_fusée1.append(ImageTk.PhotoImage(img_fusée1, master=fenetre))     # on ajoute l'image à la liste

for i in range(1,3):
    img_fleche_toile=Image.open('fleche'+str(i)+'.png')     # on ouvre l'image numéro "i" de fleche
    img_fleche_toile=img_fleche_toile.resize((25,5))   # je modifie l'image pour qu'elle soit plus grosse
    images_fleches_toile.append(ImageTk.PhotoImage(img_fleche_toile, master=fenetre))     # on ajoute l'image à la liste

img_fleche_indestructible_toile=Image.open('fleche2'+'.png')     # on ouvre l'image de fleche
img_fleche_indestructible_toile=img_fleche_indestructible_toile.resize((42,9))   # je modifie l'image pour qu'elle soit plus grosse
images_fleches_indestructible_1.append(ImageTk.PhotoImage(img_fleche_indestructible_toile, master=fenetre))     # on ajoute l'image à la liste

for i in range(1):
    img_bouclier_1=Image.open('bouclier2.png')     # on ouvre l'image qui servira de bouclier
    img_bouclier_1=img_bouclier_1.resize((30, 30))    # on redimensionne l'image par rapport à la taille du cupidon
    image_bouclier_1.append( ImageTk.PhotoImage(img_bouclier_1, master=fenetre))  # permet de pouvoir ajouter l'image à la toile



img_carapace_rouge1=Image.open('carapace_rouge0.png')     # on ouvre l'image numéro "i" des carapaces rouges
img_carapace_rouge1=img_carapace_rouge1.resize((20,20))   # je modifie l'image pour qu'elle soit plus petite
image_carapace_rouge1.append(ImageTk.PhotoImage(img_carapace_rouge1, master=fenetre))     # on ajoute l'image à la liste

img_mine=Image.open('bombe_aérienne.png')     # on ouvre l'image de la bombe aérienne
img_mine=img_mine.resize((55,73))   # je modifie l'image pour qu'elle soit plus grosse
image_mine.append(ImageTk.PhotoImage(img_mine, master=fenetre))     # on ajoute l'image à la liste

img_mine1=Image.open('bombe_aérienne.png')     # on ouvre l'image d'une bombe aérienne
img_mine1=img_mine1.resize((23,30))   # je modifie l'image pour qu'elle soit plus petite
image_mine1.append(ImageTk.PhotoImage(img_mine1, master=fenetre))     # on ajoute l'image à la liste

img_ecran_chargement=Image.open('image_chargement.jpg')     # on ouvre l'image de l'ecran de chargement
img_ecran_chargement=img_ecran_chargement.resize((largeur,hauteur))
image_fond.append(ImageTk.PhotoImage(img_ecran_chargement, master=fenetre))     # on ajoute l'image à la liste


def agrandit_limage(t):
    '''fonction qui va agrandir au fur et a mesur l'image'supercell'''
    global premiere_image,coordonnee1,coordonnee2,supercell# on prend les valeurs en global qui nous interresse
    if t==20: # si t vaut 20 alors
        coordonnee1=37 # je definis la taille de l'image
        coordonnee2=62
        supercell=Image.open('affichage_debut'+'.jpg')    # on ouvre l'image qui servira de fond d'accueil
        supercell=supercell.resize((coordonnee2,coordonnee1))    # on redimensionne l'image par rapport à la taille souhaitez
        supercell=ImageTk.PhotoImage(supercell, master=fenetre)    # on ajoute l'image à la liste
        toile.create_image(500, 300, image =supercell) # on ajoute un nouveau fond à la fenêtre
    if t<25 and t>20: # si t est superieur a 20 et inferieur a 25 alors
        coordonnee1=(coordonnee1*2) # j'augmente la taille de l'image par 2
        coordonnee2=(coordonnee2*2)
        toile.delete(supercell) # je supprime l'iage supercell
        supercell=Image.open('affichage_debut'+'.jpg')    # on ouvre l'image qui servira de fond d'accueil
        supercell=supercell.resize((coordonnee2,coordonnee1))    # on redimensionne l'image par rapport à la taille souhaitez
        supercell=ImageTk.PhotoImage(supercell, master=fenetre)     # on ajoute l'image à la liste
        toile.create_image(500, 300, image =supercell) # on ajoute un nouveau fond à la fenêtre
    if t==25: # si t vaut 25 alors :
        toile.delete(supercell) # je supprime l'image supercell
        supercell=Image.open('affichage_debut'+'.jpg')    # on ouvre l'image qui servira de fond d'accueil
        supercell=supercell.resize((1000,600))    # on redimensionne l'image par rapport à la taille souhaitez
        supercell=ImageTk.PhotoImage(supercell, master=fenetre)     # on ajoute l'image à la liste
        premiere_image=toile.create_image(500, 300, image =supercell) # on ajoute un nouveau fond à la fenêtre
    if t==90:
        musique_pour_chargement()
    if t==100 : # si t vaut 100 alors
        toile.delete(premiere_image) # je supprime la premiere image
        image_de_chargement(0) # j'applle la fonction image_de_chargement
    if t<101: # si t vaut 101 alors :
        fenetre.after(12,agrandit_limage,t+1) # on rapelle en boucle la fonction (récursivité)



def image_de_chargement(t):
    '''fonction qui afichera l'ecran de chargement de cupidon'''
    global image_barre_chargement,barre_chargement_toile,image_du_chargement,p,texte_pour_la_barre # on prend les valeurs en global qui nous interresse
    if t==0: # si t vaut 0 alors
        image_du_chargement=toile.create_image(500, 300, image =image_fond[3]) # on ajoute un nouveau fond à la fenêtre
        chargement_texte=toile.create_text(500,100,text='CUPIDON',font=('Algerian',100),fill='#FE3090')# on affiche le nom cupidon a l'ecran de chargement avec une color proche du rouge
        pbar(0) # j'appelle la fonction pbar pour afficher la barre de chargement
    if t==12: #si t vaut 12
        p.destroy() # je detruit p
        toile.delete(texte_pour_la_barre) # je supprime le texte texte_pour_la_barre
        page_d_acceuil()# j'appelle la fonction pour que la page d'acceuil soit afficher
    if t<13: # si t est in ferieur a 13 alors
        toile.after(500,image_de_chargement,t+1) # on rapelle en boucle la fonction (récursivité)

#style.configure("green.Horizontal.TProgressbar",foreground='green', background='green')
#p=ttk.Progressbar(fenetre,style="Horizontal.TProgressbar", mode='determinate', maximum=4, value=2)
p=ttk.Style() # je dis que p vaut ttk.Style() pour changer sont style et surtout sa couleur apres
p.theme_use('alt') # je dis que le theme que je vais utiliser c'est 'alt'
p.configure("red.Horizontal.TProgressbar", background='red') # je defini le changement prochaine de la couleur de la barre de chargement
p=ttk.Progressbar(fenetre,orient = HORIZONTAL,length = 320 ,maximum=100, value=12, mode = 'determinate') # je definie toutes les valeurs de la barre de chargement comme la taille sa valeur et sa position
p.config(style='red.Horizontal.TProgressbar') # je modifie la couleur de la barre de chargement et je la met en rouge

# je créer la barre de chargement

def pbar(t):
    '''fonction qui creera une barre de chargement'''
    global p,texte_pour_la_barre # on prend les valeurs en global qui nous interresse
    if t==0: # si t vaut 0 alors
        texte_pour_la_barre=toile.create_text(500,591,text='chargement ... ',font=('Bauhaus 93',15),fill='black')#et on affiche le terme chargement au dessus de la barre
        p.pack(pady=5) # j'ajoute la barre a la fenetre a 5 pixels de haut
    if t>0: # si t est superieur a 0 :
        p['value']+=9 # j'augmente 'values' de 9
    if t<12 : # si t est inferieur a 12 alors :
        toile.after(500,pbar,t+1) # on rapelle en boucle la fonction (récursivité)







py.mixer.init() # on initialise la musique

music_depart=py.mixer.Sound('son_supercell.wav') # on ouvre la musique de son_supercell.wav
music_depart.play(0)# on joue la music
music_fond = py.mixer.Sound('music_fond.wav') # on ouvre la musique de music_fond.wav
music_fond.play(0) # on joue la music
music_fond.stop() # je stop la music
music_bonus = py.mixer.Sound('bonus.wav') # on ouvre la musique de bonus.wav
music_bonus.set_volume(0.3) # on met le son de music_bonus a 30 % du volume
cupidon_toucher_son = py.mixer.Sound('mario_dead.wav') # on ouvre la musique de mario_dead.wav
bruit_explosion= py.mixer.Sound('boom.wav') # on ouvre la musique de boom.wav
mort_mechant= py.mixer.Sound('mort_mechant.wav') # on ouvre la musique de mort_mechant.wav
flecher_dans_mechant=py.mixer.Sound('plante_fleche.wav') # on ouvre la musique de plante_fleche.wav
depart_fleche=py.mixer.Sound('depart.wav') # on ouvre la musique de depart.wav
music_chargement = py.mixer.Sound('son_chargement.wav') # on ouvre la musique de son_chargement.wav
music_chargement.set_volume(0.4) # on met le son de music_chargement a 40 % du volume
music_chargement.play(0) # on joue la music
music_chargement.stop() # je stop la music



agrandit_limage(0) # j'appelle la fonction qui grandit l'image de debut pour commencer le jeu


fenetre.title('JEUX CUPIDON')
fenetre.bind('<Key>', deplacement_cupidon) # on dit que si il y a un evenement clavier il faut aller voir dans la fonction deplacement cupidon

fenetre.mainloop()  # permet à la fenêtre "d'écouter" les évènements en boucle
