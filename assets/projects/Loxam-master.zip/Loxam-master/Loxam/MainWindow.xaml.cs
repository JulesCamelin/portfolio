﻿using System;
using System.Collections.ObjectModel;
using System.Data;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media.Media3D;
using Loxam.BDD;
using Loxam.Classe;
using Npgsql;

namespace Loxam
{
    public partial class MainWindow : Window
    {
        public ObservableCollection<Client> Clients { get; set; } = new ObservableCollection<Client>();
        public ObservableCollection<Materiel> Materiels { get; set; } = new ObservableCollection<Materiel>();
        public ObservableCollection<Reservation> Reservations { get; set; } = new ObservableCollection<Reservation>();

        public Client LeClient { get; set; }

        private string connectionString;

        public MainWindow()
        {
            ChargeDataClient();
            InitializeComponent();

            LeftTabs.IsEnabled = false;
            MenuAccueil.Visibility = Visibility.Hidden;
            MenuReserv.Visibility = Visibility.Hidden;
            MenuClients.Visibility = Visibility.Hidden;
            MenuMateriel.Visibility = Visibility.Hidden;
            ConnectedText.Visibility = Visibility.Hidden;
            MenuDeconnexion.Visibility = Visibility.Hidden;
            MenuRetour.Visibility = Visibility.Hidden;
            LoginPanel.Visibility = Visibility.Visible;
        }
        public void ChargeDataClient()
        {
            try
            {
                LeClient = new Client();
                var clients = LeClient.FindAll();
                Clients.Clear();
                foreach (var client in clients)
                {
                    Clients.Add(client);
                }
                this.DataContext = this;
            }
            catch (Exception ex)
            {
            }

        }
            private void LeftTabs_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (MenuReserv == null || MenuClients == null || MenuMateriel == null)
                return;

            MenuReserv.Visibility = Visibility.Hidden;
            MenuClients.Visibility = Visibility.Hidden;
            MenuMateriel.Visibility = Visibility.Hidden;

        }

        private void Logout()
        {
            LeftTabs.IsEnabled = false;
            MenuAccueil.Visibility = Visibility.Hidden;
            MenuReserv.Visibility = Visibility.Hidden;
            MenuClients.Visibility = Visibility.Hidden;
            MenuMateriel.Visibility = Visibility.Hidden;
            MenuDeconnexion.Visibility = Visibility.Hidden;
            ConnectedText.Visibility = Visibility.Hidden;
            MenuRetour.Visibility = Visibility.Hidden;
            LoginPanel.Visibility = Visibility.Visible;

            UsernameTextBox.Text = "";
            PasswordBox.Password = "";

            MainContentControl.Content = null;
        }


        private void butConnexion_Click(object sender, RoutedEventArgs e)
        {
            DataAccess.Reset();

            string login = UsernameTextBox.Text.Trim();
            string password = PasswordBox.Password;

            if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password))
            {
                LoxamMessageBox.Show("Veuillez saisir un login et un mot de passe.");
                return;
            }

            try
            {
                DataAccess.Initialize(login, password);

                if (!DataAccess.Instance.TestConnection())
                {
                    MessageBox.Show("Échec de la connexion. Vérifiez vos identifiants.");
                    DataAccess.Reset();
                    return;
                }

                ChargeDataClient();

                LeftTabs.IsEnabled = true;
                MenuAccueil.Visibility = Visibility.Visible;
                MenuClients.Visibility = Visibility.Visible;
                MenuMateriel.Visibility = Visibility.Visible;
                MenuReserv.Visibility = Visibility.Visible;
                MenuDeconnexion.Visibility = Visibility.Visible;
                MenuRetour.Visibility = Visibility.Visible;

                LoginPanel.Visibility = Visibility.Collapsed;

                ConnectedText.Visibility = Visibility.Visible;
                ConnectedText.Text = $"Connecté en tant que \n {login}";

                MainContentControl.Content = new MenuAccueil();

                LoxamMessageBox.Show("Connexion réussie !", this);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erreur de connexion : {ex.Message}");
                DataAccess.Reset();
            }
        }


        private void MenuClients_Click(object sender, RoutedEventArgs e)
        {
            MainContentControl.Content = new RechercheClient();
        }

        private void MenuReserv_Click(object sender, RoutedEventArgs e)
        {
            MainContentControl.Content = new RechercheReservation();
        }

        private void MenuMateriel_Click(object sender, RoutedEventArgs e)
        {
            MainContentControl.Content = new RechercheMateriel();
        }



        private void MenuDeconnexion_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show("Êtes-vous sûr de vouloir vous déconnecter ?", "Confirmation", MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                Logout();

                MainContentControl.Content = null;

                DataAccess.Reset();
            }
        }

        private void MenuAccueil_Click(object sender, RoutedEventArgs e)
        {
            MainContentControl.Content = new MenuAccueil();
        }

        private void MenuRetour_Click(object sender, RoutedEventArgs e)
        {
            MainContentControl.Content = new Retour();
        }
    }
}
