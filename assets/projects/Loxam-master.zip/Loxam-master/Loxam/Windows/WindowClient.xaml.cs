﻿using System;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Loxam.Classe;

namespace Loxam.Windows
{
    public partial class WindowClient : Window
    {
        public enum  Action{ Ajouter, Modifier}
        public WindowClient(Client client, Action action)
        {
            InitializeComponent();
            this.DataContext = client;
            ButValider.Content = action == Action.Ajouter ? "Ajouter" : "Modifier";
        }

        private void butValider_Click(object sender, RoutedEventArgs e)
        {
            bool ok = true;
            foreach(UIElement uie in panelFormClient.Children)
            {
                if(uie is TextBox)
                {
                    TextBox txt = (TextBox)uie;
                    txt.GetBindingExpression(TextBox.TextProperty).UpdateSource();
                }
                if (Validation.GetHasError(uie)) 
                    ok = false;
            }
            if (ok)
            {
                DialogResult = true;
            }
        }

    }
}
