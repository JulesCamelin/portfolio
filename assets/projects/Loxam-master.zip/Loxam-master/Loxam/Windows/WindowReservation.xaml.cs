﻿using System;
using System.Windows;
using Loxam.Classe;

namespace Loxam.Windows
{
    public partial class WindowReservation : Window
    {
        private Reservation _reservation;

        public WindowReservation()
        {
            InitializeComponent();
            _reservation = new Reservation();

            // Initialiser les dates par défaut
            _reservation.DateReservation = DateTime.Now;
            _reservation.DateDebutLocation = DateTime.Now;
            _reservation.DateRetourReelleLocation = DateTime.Now.AddDays(1);

            this.DataContext = _reservation;

            // Abonnement aux événements des boutons
            butValider.Click += ButValider_Click;
            butAnnuler.Click += ButAnnuler_Click;

            // Événement pour formater les dates quand la fenêtre est chargée
            this.Loaded += WindowReservation_Loaded;
        }

        private void WindowReservation_Loaded(object sender, RoutedEventArgs e)
        {
            // Formater les dates dans le format souhaité
            txtDateReservation.Text = DateTime.Now.ToString("yyyy,MM,dd");
            txtDateDebut.Text = DateTime.Now.ToString("yyyy,MM,dd");
            txtDateRetourReelle.Text = DateTime.Now.AddDays(1).ToString("yyyy,MM,dd");
        }

        private void ButValider_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                _reservation.UnMateriel = new Materiel { NumMateriel = int.Parse(txtMateriel.Text) };
                _reservation.UnEmploye = new Employe { NumEmploye = int.Parse(txtEmploye.Text) };
                _reservation.UnClient = new Client { NumClient = int.Parse(txtClient.Text) };
                _reservation.Quantite = int.Parse(txtQuantite.Text);
                _reservation.DateReservation = DateTime.ParseExact(txtDateReservation.Text, "yyyy,MM,dd", null);
                _reservation.DateDebutLocation = DateTime.ParseExact(txtDateDebut.Text, "yyyy,MM,dd", null);
                _reservation.DateRetourEffectiveLocation = DateTime.ParseExact(txtDateRetourReelle.Text, "yyyy,MM,dd", null);
                _reservation.DateRetourReelleLocation = DateTime.ParseExact(txtDateRetourReelle.Text, "yyyy,MM,dd", null);
                _reservation.PrixTotal = decimal.Parse(txtPrix.Text);

                if (_reservation.Add())
                {
                    MessageBox.Show("Réservation ajoutée avec succès !", "Succès",
                                  MessageBoxButton.OK, MessageBoxImage.Information);
                    this.DialogResult = true;
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Erreur lors de l'ajout de la réservation.", "Erreur",
                                  MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erreur inattendue : {ex.Message}", "Erreur",
                              MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ButAnnuler_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
            this.Close();
        }
    }
}