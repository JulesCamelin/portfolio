﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Loxam.Classe;

namespace Loxam
{
    public partial class Retour : UserControl
    {
        private ObservableCollection<Reservation> ToutesLesReservations;
        private Reservation ReservationSelectionnee;

        public ObservableCollection<string> MaterialConditions { get; set; }

        public Retour()
        {
            InitializeComponent();

            ToutesLesReservations = new ObservableCollection<Reservation>();
            MaterialConditions = new ObservableCollection<string>
            {
                "Bon état",
                "Légèrement endommagé",
                "Endommagé",
                "Hors service"
            };

            this.DataContext = this;
            ChargerReservations();
            MasquerDetailsContrat();
        }

        private void ChargerReservations()
        {
            try
            {
                var reservations = new Reservation().FindAll();
                ToutesLesReservations.Clear();

                foreach (var res in reservations)
                {
                    ToutesLesReservations.Add(res);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erreur lors du chargement des réservations : {ex.Message}");
            }
        }

        private void inputNumReservation_TextChanged(object sender, TextChangedEventArgs e)
        {
            string numReservation = inputNumReservation.Text.Trim();

            if (!string.IsNullOrEmpty(numReservation))
            {
                var reservation = ToutesLesReservations.FirstOrDefault(r =>
                    r.NumReservation.ToString().Contains(numReservation));

                if (reservation != null)
                {
                    AfficherDetailsReservation(reservation);
                    inputNomClient.Text = "";
                }
                else
                {
                    MasquerDetailsContrat();
                }
            }
            else
            {
                MasquerDetailsContrat();
            }
        }

        private void inputNomClient_TextChanged(object sender, TextChangedEventArgs e)
        {
            string nomClient = inputNomClient.Text.Trim();

            if (!string.IsNullOrEmpty(nomClient))
            {
                var reservation = ToutesLesReservations.FirstOrDefault(r =>
                    r.UnClient != null &&
                    (r.UnClient.NomClient.ToLower().Contains(nomClient.ToLower()) ||
                     r.UnClient.PrenomClient.ToLower().Contains(nomClient.ToLower())));

                if (reservation != null)
                {
                    AfficherDetailsReservation(reservation);
                    inputNumReservation.Text = "";
                }
                else
                {
                    MasquerDetailsContrat();
                }
            }
            else
            {
                MasquerDetailsContrat();
            }
        }

        private void AfficherDetailsReservation(Reservation reservation)
        {
            ReservationSelectionnee = reservation;

            ContractNumReservation.Text = reservation.NumReservation.ToString();
            ContractStartDate.Text = reservation.DateDebutLocation.ToString("dd/MM/yyyy");
            ContractReturnDate.Text = reservation.DateRetourEffectiveLocation.ToString("dd/MM/yyyy");

            if (reservation.UnClient != null)
            {
                ContractReturnNom.Text = $"{reservation.UnClient.NomClient} {reservation.UnClient.PrenomClient}";
            }
            else
            {
                ContractReturnNom.Text = "Client non défini";
            }

            MaterialCondition.SelectedIndex = 0;

            DateTime dateDefaut = new DateTime(1900, 1, 1);
            bool dejaRetourne = reservation.DateRetourReelleLocation > dateDefaut;

            if (dejaRetourne)
            {
                ReturnButton.IsEnabled = false;
                ReturnButton.Content = "Déjà retourné";
            }
            else
            {
                ReturnButton.IsEnabled = true;
                ReturnButton.Content = "Retour";
            }

            CancelButton.IsEnabled = true;
        }

        private void MasquerDetailsContrat()
        {
            ReservationSelectionnee = null;

            ContractNumReservation.Text = "";
            ContractStartDate.Text = "";
            ContractReturnDate.Text = "";
            ContractReturnNom.Text = "";

            ReturnButton.IsEnabled = false;
            ReturnButton.Content = "Retour";
            CancelButton.IsEnabled = false;
        }

        private void ReturnButton_Click(object sender, RoutedEventArgs e)
        {
            if (ReservationSelectionnee == null)
            {
                MessageBox.Show("Aucune réservation sélectionnée.", "Erreur",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            DateTime dateDefaut = new DateTime(1900, 1, 1);
            if (ReservationSelectionnee.DateRetourReelleLocation > dateDefaut)
            {
                MessageBox.Show("Ce matériel a déjà été retourné.", "Information",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            try
            {
                var condition = MaterialCondition.SelectedItem?.ToString() ?? "Bon état";

                ReservationSelectionnee.DateRetourReelleLocation = DateTime.Now;

                bool success = ReservationSelectionnee.Update();

                if (success)
                {
                    if (condition != "Bon état")
                    {
                        MessageBox.Show($"Matériel retourné avec l'état : {condition}\n" +
                                      "Chèque de caution encaissé. Matériel mis en indisponibilité.",
                                      "Retour effectué", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                    else
                    {
                        MessageBox.Show("Retour effectué avec succès. Matériel en bon état.",
                                      "Retour effectué", MessageBoxButton.OK, MessageBoxImage.Information);
                    }

                    ReturnButton.IsEnabled = false;
                    ReturnButton.Content = "Déjà retourné";

                    ChargerReservations();
                }
                else
                {
                    MessageBox.Show("Erreur lors de la sauvegarde du retour.", "Erreur",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erreur lors du retour : {ex.Message}", "Erreur",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            inputNumReservation.Text = "";
            inputNomClient.Text = "";
            MasquerDetailsContrat();

            MessageBox.Show("Retour annulé.", "Information",
                MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }
}