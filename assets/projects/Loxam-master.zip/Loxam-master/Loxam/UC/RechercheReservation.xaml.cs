﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using Loxam.Classe;
using Loxam.Windows;

namespace Loxam
{
    public partial class RechercheReservation : UserControl
    {
        public ObservableCollection<Reservation> ListeReservations { get; set; }
        private ObservableCollection<Reservation> ToutesLesReservations;

        public RechercheReservation()
        {
            InitializeComponent();
            ListeReservations = new ObservableCollection<Reservation>();
            ToutesLesReservations = new ObservableCollection<Reservation>();
            dgReservation.ItemsSource = ListeReservations;
            this.DataContext = this;
            ChargerReservations();
        }

        private void ChargerReservations()
        {
            try
            {
                var reservations = new Reservation().FindAll();
                ListeReservations.Clear();
                ToutesLesReservations.Clear();

                foreach (var res in reservations)
                {
                    ListeReservations.Add(res);
                    ToutesLesReservations.Add(res);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erreur lors du chargement des réservations : {ex.Message}");
            }
        }

        private void inputNumReservation_TextChanged(object sender, TextChangedEventArgs e)
        {
            string recherche = inputNumReservation.Text.Trim();
            FiltrerReservations(recherche, inputNumMateriel.Text.Trim());
        }

        private void inputNumMateriel_TextChanged(object sender, TextChangedEventArgs e)
        {
            string recherche = inputNumMateriel.Text.Trim();
            FiltrerReservations(inputNumReservation.Text.Trim(), recherche);
        }

        private void FiltrerReservations(string numReservation, string numMateriel)
        {
            var filtres = ToutesLesReservations.Where(r =>
                (string.IsNullOrEmpty(numReservation) || r.NumReservation.ToString().Contains(numReservation)) &&
                (string.IsNullOrEmpty(numMateriel) || r.UnMateriel.NumMateriel.ToString().Contains(numMateriel))
            );

            ListeReservations.Clear();
            foreach (var res in filtres)
                ListeReservations.Add(res);
        }

        private void delete_Click(object sender, RoutedEventArgs e)
        {
                Reservation selectedClient = dgReservation.SelectedItem as Reservation;

                if (selectedClient == null)
                {
                    MessageBox.Show("Veuillez sélectionner une reservation à supprimer.", "Avertissement", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                MessageBoxResult result = MessageBox.Show(
                    $"Êtes-vous sûr de vouloir supprimer la reservation {selectedClient.NumReservation} ?",
                    "Confirmation",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Question);

                if (result == MessageBoxResult.Yes)
                {
                    var reservations = dgReservation.ItemsSource as ObservableCollection<Reservation>;
                    if (reservations != null)
                    {
                        reservations.Remove(selectedClient);
                    }
            }
        }

        private void ajouter_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                WindowReservation windowReservation = new WindowReservation();
                bool? result = windowReservation.ShowDialog();

                if (result == true)
                {
                    ChargerReservations();
                    MessageBox.Show("Réservation ajoutée avec succès !", "Succès",
                                  MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erreur lors de l'ouverture de la fenêtre d'ajout : {ex.Message}",
                               "Erreur", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
