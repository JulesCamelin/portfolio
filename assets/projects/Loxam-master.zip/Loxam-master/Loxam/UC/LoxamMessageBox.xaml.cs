﻿using System.Windows;

namespace Loxam
{
    public partial class LoxamMessageBox : Window
    {
        public LoxamMessageBox(string message)
        {
            InitializeComponent();
            MessageTextBlock.Text = message;
        }

        private void Ok_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = true;
            this.Close();
        }

        public static void Show(string message, Window owner = null)
        {
            var msgBox = new LoxamMessageBox(message);
            if (owner != null)
                msgBox.Owner = owner;
            msgBox.ShowDialog();
        }
    }
}
