﻿using System;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Loxam.BDD;
using Npgsql;

namespace Loxam
{
    public partial class clientManager : Window
    {
        public clientManager()
        {
            InitializeComponent();
        }

        private void CreateClient_Click(object sender, RoutedEventArgs e)
        {
            // Validation des champs
            bool isValid = true;

            // Vérifier le champ Nom
            if (string.IsNullOrWhiteSpace(NomTextBox.Text))
            {
                NomTextBox.BorderBrush = Brushes.Red;
                isValid = false;
            }

            // Vérifier le champ Prénom
            if (string.IsNullOrWhiteSpace(PrenomTextBox.Text))
            {
                PrenomTextBox.BorderBrush = Brushes.Red;
                isValid = false;
            }

            // Vérifier l'email
            if (!IsValidEmail(EmailTextBox.Text))
            {
                EmailTextBox.BorderBrush = Brushes.Red;
                isValid = false;
            }

            // Vérifier le téléphone
            if (!IsValidPhoneNumber(PhoneTextBox.Text))
            {
                PhoneTextBox.BorderBrush = Brushes.Red;
                isValid = false;
            }

            // Vérifier les certifications
            if (CertificationsListBox.SelectedItems.Count == 0)
            {
                MessageBox.Show("Veuillez sélectionner au moins une certification.", "Erreur", MessageBoxButton.OK, MessageBoxImage.Error);
                isValid = false;
            }

            // Si tout est valide, procéder à la création
            if (isValid)
            {
                MessageBox.Show("Fiche client créée avec succès !", "Succès", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        // Méthode de validation de l'email
        private bool IsValidEmail(string email)
        {
            if (string.IsNullOrWhiteSpace(email)) return false;
            return email.Contains("@") && email.Contains(".");
        }

        // Méthode de validation du numéro de téléphone (uniquement des chiffres)
        private bool IsValidPhoneNumber(string phone)
        {
            if (string.IsNullOrWhiteSpace(phone)) return false;
            return Regex.IsMatch(phone, @"^\d+$");
        }

        // Méthodes de validation pour les TextBox
        private void ValidateNom(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(NomTextBox.Text))
                NomTextBox.BorderBrush = Brushes.Red;
            else
                NomTextBox.BorderBrush = Brushes.Black;
        }

        private void ValidatePrenom(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(PrenomTextBox.Text))
                PrenomTextBox.BorderBrush = Brushes.Red;
            else
                PrenomTextBox.BorderBrush = Brushes.Black;
        }

        private void ValidateEmail(object sender, RoutedEventArgs e)
        {
            if (!IsValidEmail(EmailTextBox.Text))
                EmailTextBox.BorderBrush = Brushes.Red;
            else
                EmailTextBox.BorderBrush = Brushes.Black;
        }

        private void ValidatePhone(object sender, RoutedEventArgs e)
        {
            if (!IsValidPhoneNumber(PhoneTextBox.Text))
                PhoneTextBox.BorderBrush = Brushes.Red;
            else
                PhoneTextBox.BorderBrush = Brushes.Black;
        }

        // Effacer l'erreur quand l'utilisateur clique dans un champ
        private void ClearError(object sender, RoutedEventArgs e)
        {
            TextBox textBox = sender as TextBox;
            textBox.BorderBrush = Brushes.Black;
        }





        public class Client
        {
            public int Id { get; set; }
            public string Nom { get; set; }
            public string Prenom { get; set; }

            public int Create()
            {
                int id = 0;

                using (var cmdInsert = new NpgsqlCommand("INSERT INTO CLIENT (NOMCLIENT, PRENOMCLIENT) VALUES (@nom, @prenom) RETURNING NUMCLIENT"))
                {
                    cmdInsert.Parameters.AddWithValue("nom", this.Nom);
                    cmdInsert.Parameters.AddWithValue("prenom", this.Prenom);

                    id = DataAccess.Instance.ExecuteInsert(cmdInsert);
                }

                this.Id = id;
                return id;
            }
        }

        
    }
}
