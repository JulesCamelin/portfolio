﻿using System;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using Loxam.Classe;
using Loxam.Windows;

namespace Loxam
{
    public partial class RechercheClient : UserControl
    {
        public ObservableCollection<Client> lesClients { get; set; }
        private ObservableCollection<Client> tousLesClients;

        public RechercheClient()
        {
            InitializeComponent();
            lesClients = new ObservableCollection<Client>();
            tousLesClients = new ObservableCollection<Client>();
            this.DataContext = this;
            ChargerClients();
        }

        private void ChargerClients()
        {
            try
            {
                var client = new Client();
                var clients = client.FindAll();

                lesClients.Clear();
                tousLesClients.Clear();

                foreach (var c in clients)
                {
                    lesClients.Add(c);
                    tousLesClients.Add(c);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erreur lors du chargement des clients : {ex.Message}");
            }
        }

        private void inputNom_TextChanged(object sender, TextChangedEventArgs e)
        {
            string recherche = inputNom.Text.ToLower().Trim();

            lesClients.Clear();

            if (string.IsNullOrEmpty(recherche))
            {
                foreach (var client in tousLesClients)
                {
                    lesClients.Add(client);
                }
            }
            else
            {
                var clientsFiltres = tousLesClients.Where(c =>
                    c.NomClient.ToLower().Contains(recherche)
                );

                foreach (var client in clientsFiltres)
                {
                    lesClients.Add(client);
                }
            }
        }
        private void inputPrenom_TextChanged(object sender, TextChangedEventArgs e)
        {
            string recherche = inputPrenom.Text.ToLower().Trim();

            lesClients.Clear();

            if (string.IsNullOrEmpty(recherche))
            {
                foreach (var client in tousLesClients)
                {
                    lesClients.Add(client);
                }
            }
            else
            {
                var clientsFiltres = tousLesClients.Where(c =>
                    c.PrenomClient.ToLower().Contains(recherche)
                );

                foreach (var client in clientsFiltres)
                {
                    lesClients.Add(client);
                }
            }

        }

        private void delete_Click(object sender, RoutedEventArgs e)
        {
            Client selectedClient = dgClient.SelectedItem as Client;

            if (selectedClient == null)
            {
                MessageBox.Show("Veuillez sélectionner un client à supprimer.", "Avertissement", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            MessageBoxResult result = MessageBox.Show(
                $"Êtes-vous sûr de vouloir supprimer le client {selectedClient.NomClient} {selectedClient.PrenomClient} ?",
                "Confirmation",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                var clients = dgClient.ItemsSource as ObservableCollection<Client>;
                if (clients != null)
                {
                    clients.Remove(selectedClient);
                }
            }
        }
        private void ajouter_Click(object sender, RoutedEventArgs e)
        {
            Client nouveau = new Client();
            WindowClient win = new WindowClient(nouveau, WindowClient.Action.Ajouter);
            bool? result = win.ShowDialog();

            if (result == true)
            {
                try
                {
                    nouveau.Add();
                    lesClients.Add(nouveau);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Erreur lors de l'ajout : {ex.Message}");
                }
            }
        }

        private void edit_Click(object sender, RoutedEventArgs e)
        {
            if (dgClient.SelectedItem is Client clientSelectionne)
            {
                Client tempClient = new Client
                {
                    NomClient = clientSelectionne.NomClient,
                    PrenomClient = clientSelectionne.PrenomClient,
                    TelephoneClient = clientSelectionne.TelephoneClient,
                    EmailClient = clientSelectionne.EmailClient
                };

                WindowClient win = new WindowClient(tempClient, WindowClient.Action.Modifier);

                if (win.ShowDialog() == true)
                {
                    clientSelectionne.NomClient = tempClient.NomClient;
                    clientSelectionne.PrenomClient = tempClient.PrenomClient;
                    clientSelectionne.TelephoneClient = tempClient.TelephoneClient;
                    clientSelectionne.EmailClient = tempClient.EmailClient;

                    dgClient.Items.Refresh();
                }
            }
        }
    }
}