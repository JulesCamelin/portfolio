﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Loxam.Classe;

namespace Loxam
{
    public partial class RechercheMateriel : UserControl
    {
        public ObservableCollection<Materiel> ListeMateriels { get; set; }
        private ObservableCollection<Materiel> TousLesMateriels;

        public RechercheMateriel()
        {
            InitializeComponent();
            ListeMateriels = new ObservableCollection<Materiel>();
            TousLesMateriels = new ObservableCollection<Materiel>();
            this.DataContext = this;
            ChargerMateriels();
        }

        private void ChargerMateriels()
        {
            try
            {
                var materiel = new Materiel();
                var materiels = materiel.FindAll();

                ListeMateriels.Clear();
                TousLesMateriels.Clear();

                foreach (var m in materiels)
                {
                    ListeMateriels.Add(m);
                    TousLesMateriels.Add(m);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erreur lors du chargement des matériels : {ex.Message}");
            }
        }
        private void inputNomMateriel_TextChanged(object sender, TextChangedEventArgs e)
        {
            string recherche = inputNomMateriel.Text.ToLower().Trim();

            ListeMateriels.Clear();

            if (string.IsNullOrEmpty(recherche))
            {
                foreach (var materiel in TousLesMateriels)
                {
                    ListeMateriels.Add(materiel);
                }
            }
            else
            {
                var materielsFiltres = TousLesMateriels.Where(m =>
                    m.NomMateriel.ToLower().Contains(recherche)
                );

                foreach (var materiel in materielsFiltres)
                {
                    ListeMateriels.Add(materiel);
                }
            }
        }

        private void inputReference_TextChanged(object sender, TextChangedEventArgs e)
        {
            string recherche = inputReference.Text.ToLower().Trim();

            ListeMateriels.Clear();

            if (string.IsNullOrEmpty(recherche))
            {
                foreach (var materiel in TousLesMateriels)
                {
                    ListeMateriels.Add(materiel);
                }
            }
            else
            {
                var materielsFiltres = TousLesMateriels.Where(m =>
                    m.Reference.ToLower().Contains(recherche)
                );

                foreach (var materiel in materielsFiltres)
                {
                    ListeMateriels.Add(materiel);
                }
            }
        }
    }
}
