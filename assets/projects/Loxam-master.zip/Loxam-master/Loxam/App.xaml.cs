﻿using Loxam.BDD;
using System.Configuration;
using System.Data;
using System.Windows;

namespace Loxam
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        public App()
        {
            this.Exit += App_Exit;
        }
        private void App_Exit(object sender, EventArgs e)
        {
            DataAccess.Instance.CloseConnection();
        }
    }

}
