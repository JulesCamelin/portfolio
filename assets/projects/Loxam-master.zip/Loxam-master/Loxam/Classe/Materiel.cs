﻿using Loxam.BDD;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using static Loxam.clientManager;

namespace Loxam.Classe
{
    public enum Etat { Disponible, Revision, Reparation, Indisponible}
    public class Materiel : IChercher<Materiel>
    {
        private int numMateriel;
        private int numEtat;
        private int numType;
        private string reference;
        private string nomMateriel;
        private string descriptif;
        private decimal prixJournee;
        private Etat etat;

        public Materiel(int numEtat, int numType, string reference, string nomMateriel, string descriptif, decimal prixJournee)
        {
            this.NumMateriel = numMateriel;
            this.NumEtat = numEtat;
            this.NumType = numType;
            this.Reference = reference;
            this.NomMateriel = nomMateriel;
            this.Descriptif = descriptif;
            this.PrixJournee = prixJournee;
        }
        public Materiel()
        {
            // Initialisation des valeurs par défaut
        }

        public int NumMateriel
        {
            get
            {
                return this.numMateriel;
            }

            set
            {
                this.numMateriel = value;
            }
        }

        public string Reference
        {
            get
            {
                return this.reference;
            }

            set
            {
                this.reference = value;
            }
        }

        public string NomMateriel
        {
            get
            {
                return this.nomMateriel;
            }

            set
            {
                this.nomMateriel = value;
            }
        }

        public string Descriptif
        {
            get
            {
                return this.descriptif;
            }

            set
            {
                this.descriptif = value;
            }
        }

        public decimal PrixJournee
        {
            get
            {
                return this.prixJournee;
            }

            set
            {
                this.prixJournee = value;
            }
        }

        public int NumEtat
        {
            get
            {
                return this.numEtat;
            }

            set
            { 
                this.numEtat = value;
            }
        }

        public int NumType
        {
            get
            {
                return this.numType;
            }

            set
            {
                this.numType = value;
            }
        }


        public List<Materiel> FindAll()
        {
            List<Materiel> materiels = new List<Materiel>();
            using (var cmd = new NpgsqlCommand("select * from materiel"))
            {
                DataTable dt = DataAccess.Instance.ExecuteSelect(cmd);
                foreach (DataRow row in dt.Rows)
                {
                    materiels.Add(new Materiel(
                        (int)row["numetat"],
                        (int)row["numtype"],
                        (string)row["reference"],
                        (string)row["nommateriel"],
                        (string)row["descriptif"],
                        (decimal)row["prixjournee"]
                    ));
                }
            }
            return materiels;
        }
    }
}