﻿using Loxam.BDD;
using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Loxam.Classe
{
    public class Client : INotifyPropertyChanged
    {
        private int numClient;
        private string nomClient;
        private string prenomClient;
        private string telephoneClient;
        private string emailClient;

        public event PropertyChangedEventHandler? PropertyChanged;

        public Client()
        {

        }

        public Client(int numClient, string nomclient, string prenomclient, string telephoneclient, string emailclient)
        {
            this.NomClient = nomclient;
            this.PrenomClient = prenomclient;
            this.TelephoneClient = telephoneclient;
            this.EmailClient = emailclient;
            this.NumClient = numClient;
        }

        public string NomClient
        {
            get
            {
                return this.nomClient;
            }

            set
            {
                if (String.IsNullOrEmpty(value)) { throw new ArgumentException("Le nom doit être renseigné"); }
                this.nomClient = value;

                PropertyChanged?.Invoke(this,new PropertyChangedEventArgs(nameof(NomClient)));
            }
        }

        public string PrenomClient
        {
            get
            {
                return this.prenomClient;
            }

            set
            {
                if (String.IsNullOrEmpty(value)) { throw new ArgumentException("Le nom doit être renseigné"); }
                this.prenomClient = value;
                PropertyChanged?.Invoke(this,new PropertyChangedEventArgs(nameof(PrenomClient)));
            }
        }

        public string TelephoneClient
        {
            get
            {
                return this.telephoneClient;
            }

            set
            {
                if (String.IsNullOrEmpty(value)) { throw new ArgumentException("Le nom doit être renseigné"); }
                this.telephoneClient = value;
                PropertyChanged?.Invoke(this,new PropertyChangedEventArgs(nameof (TelephoneClient)));
            }
        }

        public string EmailClient
        {
            get
            {
                return this.emailClient;
            }

            set
            {
                if (String.IsNullOrEmpty(value)) { throw new ArgumentException("Le nom doit être renseigné"); }
                this.emailClient = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(EmailClient)));
            }
        }

        public int NumClient
        {
            get
            {
                return this.numClient;
            }

            set
            {
                this.numClient = value;
            }
        }
        public List<Client> FindAll()
        {
            List<Client> lesClients = new List<Client>();
            using (NpgsqlCommand cmdSelect = new NpgsqlCommand("select * from client;"))
            {
                DataTable dt = DataAccess.Instance.ExecuteSelect(cmdSelect);
                foreach (DataRow dr in dt.Rows)
                    lesClients.Add(new Client((Int32)dr["NumClient"], (String)dr["Nomclient"], (String)dr["Prenomclient"], (String)dr["Telephoneclient"], (String)dr["Emailclient"]));
            }
            return lesClients;
        }
        public bool Add()
        {
            try
            {
                using (var cmd = new NpgsqlCommand(@"
            INSERT INTO client (nomclient, prenomclient, emailclient, telephoneclient)
            VALUES (@nomclient, @prenomclient, @emailclient, @telephoneclient)
        "))
                {
                    cmd.Parameters.AddWithValue("@nomclient", NomClient);
                    cmd.Parameters.AddWithValue("@prenomclient", PrenomClient);
                    cmd.Parameters.AddWithValue("@emailclient", EmailClient);
                    cmd.Parameters.AddWithValue("@telephoneclient", TelephoneClient);
                    int affectedRows = DataAccess.Instance.ExecuteSet(cmd);
                    return affectedRows > 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de l'ajout du client : " + ex.Message);
                return false;
            }
        }

        public bool Update()
        {
            try
            {
                using (var cmd = new NpgsqlCommand(@"
            UPDATE client SET
                nomclient = @nomclient,
                prenomclient = @prenomclient,
                emailclient = @emailclient,
                telephoneclient = @telephoneclient
            WHERE numclient = @numclient
        "))
                {
                    cmd.Parameters.AddWithValue("@numclient", NumClient);
                    cmd.Parameters.AddWithValue("@nomclient", NomClient);
                    cmd.Parameters.AddWithValue("@prenomclient", PrenomClient);
                    cmd.Parameters.AddWithValue("@emailclient", EmailClient);
                    cmd.Parameters.AddWithValue("@telephoneclient", TelephoneClient);
                    int affectedRows = DataAccess.Instance.ExecuteSet(cmd);
                    return affectedRows > 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de la mise à jour du client : " + ex.Message);
                return false;
            }
        }
        public bool Delete()
        {
            try
            {
                using (var cmd = new NpgsqlCommand("DELETE FROM client WHERE numclient = @numclient"))
                {
                    cmd.Parameters.AddWithValue("@numclient", NumClient);

                    int affectedRows = DataAccess.Instance.ExecuteSet(cmd);
                    return affectedRows > 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de la suppression du client : " + ex.Message);
                return false;
            }
        }

    }
}
