﻿using Loxam.BDD;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Loxam.Classe
{
    public class Reservation : IChercher<Reservation>
    {
        private int numReservation;
        private Materiel unMateriel;
        private Client unClient;
        private Employe unEmploye;
        private int quantite;
        private DateTime dateReservation;
        private DateTime dateDebutLocation;
        private DateTime dateRetourEffectiveLocation;
        private DateTime dateRetourReelleLocation;
        private decimal prixTotal;

        public Reservation()
        {
        }

        public Reservation(int numReservation, Materiel unMateriel, Employe unEmploye, Client unClient, DateTime dateReservation, DateTime dateDebutLocation, DateTime dateRetourEffectifLocation, DateTime dateRetourReelleLocation, decimal prixTotal, int quantite)
        {
            this.NumReservation = numReservation;
            this.DateReservation = dateReservation;
            this.DateDebutLocation = dateDebutLocation;
            this.DateRetourEffectiveLocation = dateRetourEffectiveLocation;
            this.DateRetourReelleLocation = dateRetourReelleLocation;
            this.PrixTotal = prixTotal;
            this.Quantite = quantite;
            this.UnMateriel = unMateriel;
            this.UnClient = unClient;
            this.UnEmploye = unEmploye;
        }

        public int NumReservation
        {
            get
            {
                return this.numReservation;
            }
            set
            {
                this.numReservation = value;
            }
        }

        public DateTime DateReservation
        {
            get
            {
                return this.dateReservation;
            }
            set
            {
                this.dateReservation = value;
            }
        }

        public DateTime DateDebutLocation
        {
            get
            {
                return this.dateDebutLocation;
            }
            set
            {
                this.dateDebutLocation = value;
            }
        }

        public DateTime DateRetourEffectiveLocation
        {
            get
            {
                return this.dateRetourEffectiveLocation;
            }
            set
            {
                this.dateRetourEffectiveLocation = value;
            }
        }

        public DateTime DateRetourReelleLocation
        {
            get
            {
                return this.dateRetourReelleLocation;
            }
            set
            {
                this.dateRetourReelleLocation = value;
            }
        }

        public decimal PrixTotal
        {
            get
            {
                return this.prixTotal;
            }
            set
            {
                this.prixTotal = value;
            }
        }


        public int Quantite
        {
            get
            {
                return this.quantite;
            }

            set
            {
                this.quantite = value;
            }
        }

        public Materiel UnMateriel
        {
            get
            {
                return this.unMateriel;
            }

            set
            {
                this.unMateriel = value;
            }
        }

        public Client UnClient
        {
            get
            {
                return this.unClient;
            }

            set
            {
                this.unClient = value;
            }
        }

        public Employe UnEmploye
        {
            get
            {
                return this.unEmploye;
            }

            set
            {
                this.unEmploye = value;
            }
        }

        public List<Reservation> FindAll()
        {
            List<Reservation> reservations = new List<Reservation>();
            using (var cmd = new NpgsqlCommand(@"
        SELECT r.numreservation, r.nummateriel, r.numclient, r.numemploye,
               r.quantite, r.datereservation, r.datedebutlocation, 
               r.dateretoureffectivelocation, r.dateretourreellelocation, r.prixtotal,
               m.nommateriel, m.prixjournee,
               c.nomclient, c.prenomclient, c.emailclient, c.telephoneclient
        FROM reservation r
        LEFT JOIN materiel m ON r.nummateriel = m.nummateriel
        LEFT JOIN client c ON r.numclient = c.numclient"))
            {
                try
                {
                    DataTable dt = DataAccess.Instance.ExecuteSelect(cmd);
                    foreach (DataRow row in dt.Rows)
                    {
                        // Création de l'objet Materiel
                        Materiel materiel = null;
                        if (row["nummateriel"] != DBNull.Value)
                        {
                            materiel = new Materiel
                            {
                                NumMateriel = Convert.ToInt32(row["nummateriel"]),
                                NomMateriel = row["nommateriel"]?.ToString() ?? "",
                                PrixJournee = row["prixjournee"] != DBNull.Value ? Convert.ToDecimal(row["prixjournee"]) : 0
                            };
                        }

                        // Création de l'objet Employe
                        Employe employe = null;
                        if (row["numemploye"] != DBNull.Value)
                        {
                            employe = new Employe
                            {
                                NumEmploye = Convert.ToInt32(row["numemploye"])
                            };
                        }

                        // Création de l'objet Client
                        Client client = null;
                        if (row["numclient"] != DBNull.Value)
                        {
                            client = new Client
                            {
                                NumClient = Convert.ToInt32(row["numclient"]),
                                NomClient = row["nomclient"]?.ToString() ?? "",
                                PrenomClient = row["prenomclient"]?.ToString() ?? "",
                                EmailClient = row["emailclient"]?.ToString() ?? "",
                                TelephoneClient = row["telephoneclient"]?.ToString() ?? ""
                            };
                        }

                        // Gestion des dates
                        DateTime dateReservation = row["datereservation"] != DBNull.Value ?
                            Convert.ToDateTime(row["datereservation"]) : DateTime.MinValue;
                        DateTime dateDebutLocation = row["datedebutlocation"] != DBNull.Value ?
                            Convert.ToDateTime(row["datedebutlocation"]) : DateTime.MinValue;
                        DateTime dateRetourEffective = row["dateretoureffectivelocation"] != DBNull.Value ?
                            Convert.ToDateTime(row["dateretoureffectivelocation"]) : DateTime.MinValue;
                        DateTime dateRetourReelle = row["dateretourreellelocation"] != DBNull.Value ?
                            Convert.ToDateTime(row["dateretourreellelocation"]) : DateTime.MinValue;

                        // Création de la réservation
                        reservations.Add(new Reservation(
                            Convert.ToInt32(row["numreservation"]),
                            materiel,
                            employe,
                            client,
                            dateReservation,
                            dateDebutLocation,
                            dateRetourEffective,
                            dateRetourReelle,
                            row["prixtotal"] != DBNull.Value ? Convert.ToDecimal(row["prixtotal"]) : 0,
                            row["quantite"] != DBNull.Value ? Convert.ToInt32(row["quantite"]) : 0
                        ));
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Erreur SQL: {ex.Message}");
                }
            }
            return reservations;
        }
        public bool Delete()
        {
            try
            {
                using (var cmd = new NpgsqlCommand("DELETE FROM reservation WHERE numreservation = @numreservation"))
                {
                    cmd.Parameters.AddWithValue("@numreservation", NumReservation);
                    int affectedRows = DataAccess.Instance.ExecuteSet(cmd);
                    return affectedRows > 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de la suppression : " + ex.Message);
                return false;
            }
        }
        public bool Add()
        {
            try
            {
                using (var cmd = new NpgsqlCommand(@"
            INSERT INTO reservation (nummateriel,numemploye, numclient, quantite, datereservation, datedebutlocation, dateretoureffectivelocation, prixtotal)
            VALUES (@nummateriel,@numemploye, @numclient, @quantite, @datereservation, @datedebut, @dateretoureffectivelocation, @prixtotal)
        "))
                {
                    cmd.Parameters.AddWithValue("@nummateriel", UnMateriel.NumMateriel);
                    cmd.Parameters.AddWithValue("@numemploye", UnEmploye.NumEmploye);
                    cmd.Parameters.AddWithValue("@numclient", UnClient.NumClient);
                    cmd.Parameters.AddWithValue("@quantite", Quantite);
                    cmd.Parameters.AddWithValue("@datereservation", DateReservation);
                    cmd.Parameters.AddWithValue("@datedebut", DateDebutLocation);
                    cmd.Parameters.AddWithValue("@dateretoureffectivelocation", DateRetourEffectiveLocation);
                    cmd.Parameters.AddWithValue("@prixtotal", PrixTotal);

                    int affectedRows = DataAccess.Instance.ExecuteSet(cmd);
                    return affectedRows > 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de l'ajout de la réservation : " + ex.Message);
                return false;
            }
        }
        public bool Update()
        {
            bool ok = false;
            return ok;
        }
    }

}
