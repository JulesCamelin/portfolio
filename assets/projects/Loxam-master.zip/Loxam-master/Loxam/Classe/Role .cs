﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Loxam.Classe
{
    public class Role
    {
        private int numRole;
        private int numemploye;
        private string nomRole;

        public int NumRole
        {
            get
            {
                return this.numRole;
            }

            set
            {
                this.numRole = value;
            }
        }

        public int NumEmploye
        {
            get
            {
                return this.numemploye;
            }

            set
            {
                this.numemploye = value;
            }
        }

        public string NomRole
        {
            get
            {
                return this.nomRole;
            }

            set
            {
                this.nomRole = value;
            }
        }
    }
}
