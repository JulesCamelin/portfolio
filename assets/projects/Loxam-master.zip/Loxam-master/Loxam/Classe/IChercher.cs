﻿using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Loxam.Classe
{
    public interface IChercher<T>
    {
        public List<T> FindAll();
    }
}